
// ------------------
// Vehicle VRM Functions
// ------------------

function resetSpecs(){

	$('#variant').val('');
	$('#variant').attr('placeholder','Search Variants (..)');
	$('#variant_suggestions').empty();

	$('#colour_id').val('');
	$('#engine_cc').val('');
	$('#year').val('');
	$('#fuel_type_id').val('');
	$('#transmission_type_id').val('');
}

function populateForm(){
	var formObj = $('#vehicle_form');
	var number_plate = $('#number_plate').val();

	$.ajax({
		type: 		'GET',
		url:		'ajax_get_vehicles/' + number_plate,
		dataType:	'JSON',
		cache: 		false,
		success: 	function( data, textStatus , jqXHR){
						var entries = Object.entries(data[0]);
						var model_id;
						var notes;

						resetForm();
						for(var i = 0; i < entries.length; i++){
							var key = entries[i][0];
							var value = entries[i][1];
							var elem = formObj.find('[name="' + key + '"]');

							if(key == 'notes'){
								notes = value;
								continue;
							}
							if(key == 'odo_unit'){
								$('#odo_' + value).attr('checked',true);
								continue;
							}
							if(elem.length > 0 && key != 'number_plate' && key != 'hidden'){
								if(key == 'model_id'){
									model_id = value;
									continue;
								}
								elem.val(value);
							}
						}

						populateModelOptions();

						setTimeout(function(){
							$('#model_id').val(model_id);
							CKEDITOR.instances['notes'].setData(notes);
							populateVariantOptions();
						}, 250);
					},
		error: 		function( data, textStatus , jqXHR){
						console.log('Failed to populate form');
					}
	});
}

function populateModelOptions(){
	let make_id = $('#make_id').val();
	$('#model_id').empty().append(new Option("Select Model", ""));

	$.ajax({
			type: 		'GET',
			url:		'ajax_get_models/' + make_id,
			dataType:	'JSON',
			cache: 		false,
			success: 	function( data, textStatus , jqXHR)
						{
							for(var i = 0; i < data.length; i++){
								var option = new Option(data[i].model, data[i].id);
								$(option).attr("data-mgmodelid", data[i].mg_model_id);
								$('#model_id').append($(option));
							}
						},
			error: 		function( data, textStatus , jqXHR)
						{
							console.log('failure to populateModelOptions');
						}
	});
}

function populateVariantOptions(){
	let make_id = $('#make_id').val();
	let model_id = $('#model_id').val();

	if(model_id == ""){
		$('#variant_suggestions').empty();
	}
	else{
		$.ajax({
			url: 	 	'ajax_get_variants',
			dataType:	'JSON',
			type: 	 	'POST',
			data: 		 $('#vehicle_form').serialize(),
			error: 	 	function() {
							console.log('Something is wrong');
						},
			success: 	function(data) {
							$('#variant_suggestions').empty();
							$('#variant').attr("placeholder", "Search Variants (" + data.length + ")");
							for(var i = 0; i < data.length; i++){
								var optionHtml = '<option ';
								optionHtml += ' data-variant_id="' + data[i].variant_id + '" '
								optionHtml += ' data-mg_car_id="' + data[i].mg_car_id + '" '
								optionHtml += ' data-model_from_f="' + data[i].model_from_f + '" '
								optionHtml += ' data-model_to_f="' + data[i].model_to_f + '" '
								optionHtml += ' data-engine_power_ps="' + data[i].engine_power_ps + '" '
								optionHtml += ' data-engine_cc="' + data[i].engine_cc + '" '
								optionHtml += ' value="' + data[i].variant + '" '
								optionHtml += '></option>'
								$('#variant_suggestions').append(optionHtml);
							}
					 }
		});
	}
}

function resetForm(){
	$('.form-control').each(function(i, obj) {
		if($(this).attr('id') != 'number_plate'){
			$(this).val('');
		}
	});
}


// ------------------
// Customer Eircode Functions
// ------------------

function getEircodeDetails(input_text){

	var eircode = input_text.replace(" ", "").toUpperCase();
	if(eircode.length != 7){
		alert('Eircode must be 7 characters');
		return false;
	}
	$.ajax({
		type: 		'GET',
		url:		'ajax_get_address/' + eircode,
		dataType:	'JSON',
		cache: 		false,
		success: 	function( data, textStatus , jqXHR){
						var match = false;
						for(var i = 0; i < data.length; i++){
							if(data[i].eircode == eircode){
								match = true;
								$('#address1').val(data[i].addr_line1);
								$('#address2').val(data[i].addr_line2);
								if(data[i].addr_line3.substring(0, 3) == 'Co.')
									$('#address3').attr('placeholder','').val('');
								else
									$('#address3').val(data[i].addr_line3);
								$('#county').val(data[i].post_county);
								return;
							}
						}
						if(!(match))
							alert("No match for '" + eircode + "'");
					},
		error: 		function( data, textStatus , jqXHR){
						alert('This Eircode could not be found');
					}
	});

}


// ------------------
// Common Functions
// ------------------

function delete_item(delete_url, item_id, item_desc){
	if (confirm("Are you sure you want to remove this?")) {
		$.ajax({
			url: 	 	delete_url,
			type: 	 	'POST',
			data: 		{  id: item_id },
			error: 	 	function() {
							console.log('Something is wrong');
						},
			success: 	function(data) {
							console.log("success");
							$('tr#' + item_id).fadeOut(200, function() {
								$(this).remove();
								$('.idx').each(function(i, obj) {
									$(this).html(i+1);
								});
							});
							$('.js-message').find('p').html("'" + item_desc + "' successfully deleted");
							$('.js-message').fadeIn(900);
						}
		});
	} else {
		return false;
	}
}



