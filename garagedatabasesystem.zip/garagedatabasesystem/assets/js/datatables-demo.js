// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#data-table').DataTable();
});
