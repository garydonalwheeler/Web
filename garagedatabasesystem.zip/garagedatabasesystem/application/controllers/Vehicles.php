<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vehicles extends CI_Controller{

	public function index(){
		if(!$this->session->userdata('logged_in')){
			redirect(); // if not logged in, redirect to default/home page
		}
		$data['title'] = 'Vehicles';
		$stock_args["hidden"] = 0;
		$data['stock'] = $this->vehicle_model->get_vehicle_stock($stock_args);
		$this->load->view('includes/header', $data);
		$this->load->view('vehicles/index', $data);
		$this->load->view('includes/footer');
	}

	public function view($vehicle_id = 0){
		if(!$this->session->userdata('logged_in')){
			redirect(); // if not logged in, redirect to default/home page
		}
		$data['stock_item'] = NULL;
		$data['vehicle_id'] = $vehicle_id;

		// variant defaults (set to 0 first avoid errors on create page)
		$data['title'] = 'Create New Vehicle Record';
		$data['hidden'] = 0;
		$data['variant_id'] = 0;
		$data['mg_car_id'] = 0;
		$data['model_from_f'] = '';
		$data['model_to_f'] = '';
		$data['engine_power_ps'] = 0;

		// Dropdowns + datalists
		$data['makes'] =  $this->vehicle_model->get_vehicle_makes();
		$data['colours'] =  $this->vehicle_model->get_vehicle_colours();
		$data['fuel_types'] =  $this->vehicle_model->get_vehicle_fuel_types();
		$data['transmission_types'] =  $this->vehicle_model->get_vehicle_transmissions();
		$data['customers'] =  $this->vehicle_model->get_vehicle_customers();

		// Suggest adding back deleted (when adding new car)
		$data['deleted_vehicles'] = $this->vehicle_model->get_vehicle_stock((array("hidden"=> 1, "sidx"=> 'number_plate', "sord"=> 'ASC')));

		// If updating a vehicle
		if($vehicle_id > 0){
			$data['title'] = 'Edit Vehicle Record';
			$stock_args["slug"] = $vehicle_id;
			$stock_matches = $this->vehicle_model->get_vehicle_stock($stock_args);

			if(count($stock_matches) < 1){
				$this->session->set_flashdata('no_record', 'Vehicle record ' . $vehicle_id . ' does not exist');
				redirect('vehicles');
			}
			$data['stock_item'] = $stock_matches[0];

			// Variant
			$data['variant_id'] = $data['stock_item']['variant_id'];
			$data['hidden'] = $data['stock_item']['hidden'];
			$data['mg_car_id'] = $data['stock_item']['mg_car_id'];
			$data['model_from_f'] = $data['stock_item']['model_from_f'];
			$data['model_to_f'] = $data['stock_item']['model_to_f'];
			$data['engine_power_ps'] = $data['stock_item']['engine_power_ps'];

			// Makes
			$vehicle_make_id = $data['stock_item']['make_id'];
			$models_args["make_id"] = $vehicle_make_id;
			$data['models'] =  $this->vehicle_model->get_vehicle_models($models_args);

			// Variant suggestions list
			$variant_args["make_id"] = $data['stock_item']['make_id'];
			$variant_args["model_id"] = $data['stock_item']['model_id'];
			$variant_args["engine_cc"] = $data['stock_item']['engine_cc'];
			$variant_args["year"] = $data['stock_item']['year'];
			$data['variants'] =  $this->vehicle_model->get_vehicle_variant($variant_args);
		}

		$this->load->view('includes/header', $data);
		$this->load->view('vehicles/view', $data);
		$this->load->view('includes/footer');
	}


	public function create(){
		if(!$this->session->userdata('logged_in')){
			redirect(); // if not logged in, redirect to default/home page
		}

		// check if car already in db (previosly deleted)
		$number_plate = $this->input->post('number_plate');
		$plate_matches = $this->vehicle_model->get_vehicle_stock(array("reg_no"=> $number_plate));

		if(count($plate_matches) > 0){
			$this->vehicle_model->update_vehicle();
			$this->session->set_flashdata('vehicle_restored', "Vehicle '" . $number_plate . "' restored");
			$vehicle_id = $plate_matches[0]["id"];
		}
		else{
			$new_record = $this->vehicle_model->create_vehicle();
			$this->session->set_flashdata('vehicle_created', "Vehicle '" . $number_plate . "' created");
			$vehicle_id = $new_record;
		}
		redirect('vehicles/' . $vehicle_id);
	}

	public function update(){
		if(!$this->session->userdata('logged_in')){
			redirect(); // if not logged in, redirect to default/home page
		}
		$vehicle_id = $this->input->post('id');
		$number_plate = $this->input->post('number_plate');
		$this->vehicle_model->update_vehicle();
		$this->session->set_flashdata('vehicle_updated', "Vehicle '" . $number_plate . "' updated");
		redirect('vehicles/' . $vehicle_id);
	}

	public function delete(){
		if(!$this->session->userdata('logged_in')){
			redirect(); // if not logged in, redirect to default/home page
		}
		$this->vehicle_model->delete_vehicle();
	}

	public function ajax_get_models($make_id = 0){
		$model_args["make_id"] = $make_id;
		$models =  $this->vehicle_model->get_vehicle_models($model_args);
		$results_json = json_encode($models);
		echo $results_json;
	}

	public function ajax_get_variants(){
		$model_args["make_id"] = $this->input->post('make_id');
		$model_args["model_id"] = $this->input->post('model_id');
		$model_args["engine_cc"] = $this->input->post('engine_cc');
		$model_args["year"] = $this->input->post('year');

		$variants =  $this->vehicle_model->get_vehicle_variant($model_args);
		$results_json = json_encode($variants);
		echo $results_json;
	}

	public function ajax_get_vehicles($reg_no=""){
		$plate_matches = $this->vehicle_model->get_vehicle_stock(array("reg_no"=> $reg_no));
		if(count($plate_matches) > 0){
			// Car already in database
			$results_json = json_encode($plate_matches);
			echo $results_json;
		}
		else{
			// Car NOT in database - get details from API
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => "https://liveservices.micksgarage.com/gatewayservice/api/CarRegistration/GetCar?CarRegistrationNumber=" . $reg_no . "&CountryCode=IE",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 0,
				CURLOPT_FOLLOWLOCATION => true,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array("Content-Type: application/json"),
			));
			$response_json = curl_exec($curl);
			$response_arr = json_decode($response_json, true)[0]; // Convert JSON response to PHP array

			// insert into 'vehicle_stock' table
			$variant_matches = $this->vehicle_model->get_vehicle_variant(array("mg_car_id"=> $response_arr["CarID"]));
			$nct_due_date = date_format(date_create($response_arr["NctDueDate"]),"d/m/Y");

			// Reg Year
			$reg_year = "";
			if(is_numeric ( substr($reg_no, 0, 2)) ){
				$reg_year = DateTime::createFromFormat('y', substr($reg_no, 0, 2))->format('Y'); // Irish reg
			}
			if(is_numeric ( substr($reg_no, 2, 2)) ){
				$reg_year = substr($reg_no, 2, 2) > 50 ? 1950 + substr($reg_no, 2, 2) : 2000 + substr($reg_no, 2, 2); // UK Reg
			}

			if(count($variant_matches) > 0){
				// if match for 'mg_car_id' 'vehicle_variants'
				$details = $variant_matches[0];
				$details["nct_due_date_f"] = $nct_due_date; // need to add nct to this array
				$details["year"] = $reg_year; // need to add year to this array
				$details_json = json_encode(Array($details));
			}
			else{
				// if no match in 'vehicle_variants'
				// insert into 'vehicle_variant' table
				$model =  $this->vehicle_model->get_vehicle_models(array("mg_base_model"=> $response_arr["Basemodel"]))[0];
				$variants =  $this->vehicle_model->get_vehicle_variant(array("model_id"=> $model["id"]));

				$details_arr = array(
					"engine_cc" => $response_arr["CC"],
					"make_id" => $model["make_id"],
					"model_id"=> $model["id"],
					"mg_car_id"=> $response_arr["CarID"],
					"model_from_f"=> '01/' . $response_arr["YearFrom"],
					"model_to_f"=> '01/' . $response_arr["YearTo"],
					"engine_power_ps"=> $response_arr["BHP"],
					"nct_due_date_f" => $nct_due_date,
					"variant"=> $response_arr["Car"].' (' .$response_arr["CC"] . 'cc) | ' . $response_arr["BHP"] . ' BHP (' . substr($response_arr["YearFrom"], -4) . "-'" . substr($response_arr["YearTo"], -2) .')',
					"model_variants"=> $variants,
					"year"=> $reg_year
				);
				$details_json = json_encode(Array($details_arr));
			}
			curl_close($curl);
			echo $details_json;
		}

	}


}