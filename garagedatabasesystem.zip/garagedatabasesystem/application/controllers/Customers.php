<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customers extends CI_Controller{

	public function index(){
		if(!$this->session->userdata('logged_in')){
			redirect(); // if not logged in, redirect to default/home page
		}
		$data['title'] = 'Customers';
		$data['customers'] = $this->customer_model->get_customers();
		$this->load->view('includes/header', $data);
		$this->load->view('customers/index', $data);
		$this->load->view('includes/footer');
	}

	public function view($customer_id = 0){
		if(!$this->session->userdata('logged_in')){
			redirect();
		}
		$title = 'Create New Customer Record';
		$form_url = 'customers/create';
		$new_record = true;
		$details = Array();

		// Non-numeric ID - check if ID in database
		$records = $this->customer_model->get_customers(Array('id'=>$customer_id));

		// If updating a customer
		if(count($records) > 0){
			$title = 'Edit Customer Record: ' . $customer_id;
			$form_url = 'customers/update';
			$new_record = false;
			$details = $records[0];
		}

		$data = Array(
			'title'=> $title,
			'form_url'=> $form_url,
			'id'=> $new_record ? '' : $details['id'],
			'customer_name'=> $new_record ? '' : $details['customer_name'],
			'address'=> $new_record ? '' : $details['address'],
			'address1'=> $new_record ? '' : $details['address1'],
			'address2'=> $new_record ? '' : $details['address2'],
			'address3'=> $new_record ? '' : $details['address3'],
			'county'=> $new_record ? '' : $details['county'],
			'country_id'=> $new_record ? '' : $details['country_id'],
			'eir_code'=> $new_record ? '' : $details['eir_code'],
			'phone'=> $new_record ? '' : $details['phone'],
			'status'=> $new_record ? '' : $details['status'],
			'status_list'=> $this->customer_model->get_status(),
			'county_list'=> $this->customer_model->get_counties(),
			'country_list'=> $this->customer_model->get_countries(),
			'email'=> $new_record ? '' : $details['email'],
			'created_at'=> $new_record ? '' : $details['created_at']
		);

		$this->load->view('includes/header', $data);
		$this->load->view('customers/view', $data);
		$this->load->view('includes/footer');
	}

	public function create(){
		if(!$this->session->userdata('logged_in')){
			redirect();
		}
		$new_record = $this->customer_model->create_customer();
		$this->session->set_flashdata('customer_created', "Customer '" . $this->input->post('customer_name') . "' created");
		redirect('customers/' . $this->input->post('id'));
	}

	public function update(){
		if(!$this->session->userdata('logged_in')){
			redirect();
		}
		$customer_id = $this->input->post('id');
		$this->customer_model->update_customer();
		$this->session->set_flashdata('customer_updated', "Customer '" . $this->input->post('customer_name') . "' updated");
		redirect('customers/' . $customer_id);
	}

	public function delete(){
		if(!$this->session->userdata('logged_in')){
			redirect();
		}
		$this->customer_model->delete_customer();
	}

	public function ajax_get_address($eircode=""){
		$curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_URL => "https://www.bonkers.ie/eircode.js/?address=" . $eircode,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => array("Content-Type: application/json"),
		));
		$response_json = curl_exec($curl);
		echo $response_json;
	}

}