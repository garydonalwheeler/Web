<?php
class Vehicle_model extends CI_Model{
	public function __construct(){
		$this->load->database();
	}

	public function get_vehicle_stock($args = Array()){
		// if($limit){
		// 	$this->db->limit($limit, $offset);
		// }
		$this->db->select("
			 vehicle_stock.*
			,DATE_FORMAT(vehicle_stock.nct_due_date,'%d/%m/%Y') AS nct_due_date_f
			,DATE_FORMAT(vehicle_stock.next_service,'%d/%m/%Y') AS next_service_f
			,vehicle_colour.colour
			,vehicle_fuel.fuel
			,vehicle_make.id 									AS make_id
			,vehicle_make.make
			,vehicle_make.mg_make_id
			,vehicle_model.id 									AS model_id
			,vehicle_model.model
			,vehicle_model.mg_model_id
			,vehicle_variant.id 								AS variant_id
			,vehicle_variant.variant
			,vehicle_variant.mg_car_id
			,vehicle_variant.model_year
			,DATE_FORMAT(vehicle_variant.model_from,'%d/%m/%Y') AS model_from_f
			,DATE_FORMAT(vehicle_variant.model_to,'%d/%m/%Y') 	AS model_to_f
			,vehicle_variant.body_type_id
			,vehicle_variant.engine_cc
			,vehicle_variant.engine_power_ps
			,vehicle_variant.fuel_type_id
			,vehicle_variant.transmission_type_id
		");
		$this->db->from( 'vehicle_stock' );
		$this->db->join( 'vehicle_make', 'vehicle_stock.make_id = vehicle_make.id', 'LEFT' );
		$this->db->join( 'vehicle_model', 'vehicle_stock.model_id = vehicle_model.id', 'LEFT' );
		$this->db->join( 'vehicle_variant', 'vehicle_stock.variant_id = vehicle_variant.id', 'LEFT' );
		$this->db->join( 'vehicle_colour', 'vehicle_stock.colour_id = vehicle_colour.id', 'LEFT' );
		$this->db->join( 'vehicle_fuel', 'vehicle_variant.fuel_type_id = vehicle_fuel.id', 'LEFT' );
		$this->db->join( 'vehicle_body', 'vehicle_variant.body_type_id = vehicle_body.id', 'LEFT' );
		//$this->db->join( 'vehicle_transmission', 'vehicle_variant.transmission_type_id = vehicle_transmission.id', 'LEFT' );

		// Hidden/deleted
		if(array_key_exists("hidden",$args))
			$this->db->where( 'vehicle_stock.hidden', $args['hidden'] );

		// filter by number plate (exact)
		if(array_key_exists("reg_no",$args) && $args['reg_no'] )
			$this->db->where( 'vehicle_stock.number_plate', $args['reg_no'] );

		// Slug
		if(array_key_exists("slug",$args) && $args['slug'] )
			$this->db->where( 'vehicle_stock.id', $args['slug'] );

		// mg_car_id
		if(array_key_exists("mg_car_id",$args) && $args['mg_car_id'] )
			$this->db->where( 'vehicle_variant.mg_car_id', $args['mg_car_id'] );

		// Sort column/index and order
		$sort_index = array_key_exists("sidx",$args) && $args['sidx'] ? $args['sidx'] : 'vehicle_stock.ID';
		$sort_order = array_key_exists("sord",$args) && $args['sord'] ? $args['sord'] : 'ASC';
		$this->db->order_by($sort_index, $sort_order);

		$query = $this->db->get();
		$results_arr = $query->result_array();  	// $query->result_array() returns multiple results. $query->row_array() returns a single result

		// Get alternative variants for each model and append to results (suggestions)
		if(array_key_exists("slug",$args) && $args['slug'] ){
			// Performance hit on MySQL - only get variants for a single record
			$results_arr_modified = array();
			foreach ($results_arr as $vehicle) {
				$variant_args["model_id"] = $vehicle['model_id'];
				$model_variants =  $this->vehicle_model->get_vehicle_variant($variant_args);
				$vehicle += count($model_variants) > 0 ? ['model_variants' => $model_variants] : ['model_variants' => array(array())];
				array_push($results_arr_modified, $vehicle);
			}
			return $results_arr_modified;
		}
		return $results_arr;
	}


	public function get_vehicle_variant($args = Array()){
		$this->db->select("
			 vehicle_variant.id 									AS variant_id
			,vehicle_variant.variant
			,vehicle_variant.model_id
			,vehicle_variant.mg_car_id
			,vehicle_variant.body_type_id
			,vehicle_variant.engine_cc
			,vehicle_variant.engine_power_ps
			,vehicle_variant.fuel_type_id
			,vehicle_variant.transmission_type_id
			,DATE_FORMAT(vehicle_variant.model_from,'%d/%m/%Y') 	AS model_from_f
			,DATE_FORMAT(vehicle_variant.model_to,'%d/%m/%Y') 		AS model_to_f
			,vehicle_make.id 										AS make_id
			,vehicle_make.make
			,vehicle_model.model
			,vehicle_fuel.fuel
			,vehicle_body.body
			,vehicle_transmission.transmission
		");
		$this->db->from( 'vehicle_variant' );
		$this->db->join( 'vehicle_model', 'vehicle_variant.model_id = vehicle_model.id', 'LEFT' );
		$this->db->join( 'vehicle_make', 'vehicle_model.make_id = vehicle_make.id', 'LEFT' );
		$this->db->join( 'vehicle_fuel', 'vehicle_variant.fuel_type_id = vehicle_fuel.id', 'LEFT' );
		$this->db->join( 'vehicle_body', 'vehicle_variant.body_type_id = vehicle_body.id', 'LEFT' );
		$this->db->join( 'vehicle_transmission', 'vehicle_variant.transmission_type_id = vehicle_transmission.id', 'LEFT' );

		// variant id
		if(array_key_exists("id",$args) && $args['id'] )
			$this->db->where( 'vehicle_variant.id', $args['id'] );

		// variant desc
		if(array_key_exists("variant",$args) && $args['variant'] )
			$this->db->where( 'vehicle_variant.variant', $args['variant'] );

		// mg_car_id
		if(array_key_exists("mg_car_id",$args) && $args['mg_car_id'] )
			$this->db->where( 'vehicle_variant.mg_car_id', $args['mg_car_id'] );

		// make_id
		if(array_key_exists("make_id",$args) && $args['make_id'] )
			$this->db->where( 'vehicle_model.make_id', $args['make_id'] );

		// model_id
		if(array_key_exists("model_id",$args) && $args['model_id'] )
			$this->db->where( 'vehicle_variant.model_id', $args['model_id'] );

		// engine_cc
		if(array_key_exists("engine_cc",$args) && $args['engine_cc'] )
			$this->db->where( "(vehicle_variant.engine_cc > (" . $args['engine_cc'] . " - 100) AND vehicle_variant.engine_cc < (" . $args['engine_cc'] . " + 100))");

		// year
		if(array_key_exists("year",$args) && $args['year'] )
			$this->db->where( "(vehicle_variant.model_year = " . $args['year'] . " OR (vehicle_variant.model_year < " . $args['year'] . " AND vehicle_variant.model_year >= (" . $args['year'] . " - 3)))");

		$this->db->order_by('vehicle_make.make ASC, vehicle_model.model ASC, vehicle_variant.variant ASC, vehicle_variant.model_year ASC');
		$query = $this->db->get();

		return $query->result_array();
	}

	public function get_vehicle_colours(){
		$this->db->distinct();
		$this->db->select( 'vehicle_colour.id, vehicle_colour.colour' );
		$this->db->from( 'vehicle_colour' );
		// $this->db->join( 'stock', 'stock.colour_id = vehicle_colour.id', 'inner' );
		$this->db->where( 'vehicle_colour.hidden', 0 );
		$this->db->order_by('vehicle_colour.colour', 'ASC');
		$query = $this->db->get();
		return $query->result_array();
	}

	public function get_vehicle_makes(){
		$this->db->distinct();
		$this->db->select('vehicle_make.id, vehicle_make.make, vehicle_make.mg_make_id');
		$this->db->from( 'vehicle_make' );
		// $this->db->join( 'stock', 'stock.make_id = makes.id', 'inner' );
		$this->db->where( 'vehicle_make.hidden', 0 );
		$this->db->order_by('vehicle_make.make', 'ASC');
		$query = $this->db->get();
		return $query->result_array();
	}

	public function get_vehicle_models($args = Array()){
		$this->db->distinct();
		$this->db->select( ' vehicle_model.id
							,vehicle_make.make
							,vehicle_model.model
							,vehicle_model.make_id
							,vehicle_model.mg_model_id' );
		$this->db->from( 'vehicle_model' );
		$this->db->join( 'vehicle_make', 'vehicle_make.id = vehicle_model.make_id', 'inner' );

		if(array_key_exists("make_id",$args) && $args['make_id'] )
			$this->db->where( 'vehicle_model.make_id', $args['make_id'] );

		if(array_key_exists("mg_base_model",$args) && $args['mg_base_model'] )
			$this->db->where( 'vehicle_model.mg_base_model', $args['mg_base_model'] );

		if(array_key_exists("mg_model_id",$args) && $args['mg_model_id'] )
			$this->db->where( 'vehicle_model.mg_model_id', $args['mg_model_id'] );

		$this->db->order_by('vehicle_model.model', 'ASC');
		$query = $this->db->get();
		return $query->result_array();
	}

	public function get_vehicle_transmissions(){
		$this->db->distinct();
		$this->db->select( 'vehicle_transmission.id, vehicle_transmission.transmission' );
		$this->db->from( 'vehicle_transmission' );
		$this->db->order_by('vehicle_transmission.transmission', 'ASC');
		$query = $this->db->get();
		return $query->result_array();
	}

	public function get_vehicle_fuel_types(){
		$this->db->distinct();
		$this->db->select( 'vehicle_fuel.id, vehicle_fuel.fuel' );
		$this->db->from( 'vehicle_fuel' );
		$this->db->order_by('vehicle_fuel.fuel', 'ASC');
		$query = $this->db->get();
		return $query->result_array();
	}

	public function get_vehicle_customers($customer_id = ""){
		$this->db->select( 'customers.id, customers.customer_name' );
		$this->db->from( 'customers' );
		if($customer_id != ""){
			$this->db->where( 'customers.id', $customer_id );
		}
		$this->db->order_by('customers.customer_name', 'ASC');
		$query = $this->db->get();
		return $query->result_array();
	}

	public function create_vehicle(){

		// INSERT or UPDATE vehicle_variant table
		$variant_id = $this->input->post('variant_id');

		// Convert dates from dd/mm/yyyy to yyyy-mm-dd
		$model_from =  empty($this->input->post('model_from_f')) ? date_create($this->input->post('year') . "-01-1")->format('Y-m-d') : DateTime::createFromFormat('d/m/Y', $this->input->post('model_from_f'))->format('Y-m-d');
		$model_to =  empty($this->input->post('model_to_f')) ? date_create($this->input->post('year') . "-12-31")->format('Y-m-d') : DateTime::createFromFormat('d/m/Y', $this->input->post('model_to_f'))->format('Y-m-d');

		$data = array(
			'variant' => $this->input->post('variant'),
			'model_id' => $this->input->post('model_id'),
			'mg_car_id' => $this->input->post('mg_car_id'),
			'model_year' => $this->input->post('year'),
			'model_from' => $model_from,
			'model_to' => $model_to,
			'body_type_id' => $this->input->post('body_type_id'),
			'engine_cc' => $this->input->post('engine_cc'),
			'engine_power_ps' => $this->input->post('engine_power_ps'),
			'fuel_type_id' => $this->input->post('fuel_type_id'),
			'transmission_type_id' => $this->input->post('transmission_type_id')
		);
		if($variant_id == 0){
			$this->db->insert('vehicle_variant', $data); // INSERT INTO vehicle_variant table
			$variant_id = $this->db->insert_id();
		}
		else{
			$this->db->where('id', $variant_id);
			$this->db->update('vehicle_variant', $data); // UPDATE vehicle_variant table
		}

		// INSERT INTO vehicle_stock table
		$next_service =  empty($this->input->post('next_service_f')) ? NULL : DateTime::createFromFormat('d/m/Y', $this->input->post('next_service_f'))->format('Y-m-d');
		$nct_due_date =  empty($this->input->post('nct_due_date_f')) ? NULL : DateTime::createFromFormat('d/m/Y', $this->input->post('nct_due_date_f'))->format('Y-m-d');
		$data = array(
			'number_plate' => strtoupper($this->input->post('number_plate')),
			'customer_id' => $this->input->post('customer_id'),
			'make_id' => $this->input->post('make_id'),
			'model_id' => $this->input->post('model_id'),
			'variant_id' => $variant_id,
			'vin' => strtoupper($this->input->post('vin')),
			'next_service' => $next_service,
			'nct_due_date' => $nct_due_date,
			'year' => $this->input->post('year'),
			'colour_id' => $this->input->post('colour_id'),
			'last_mileage' => $this->input->post('last_mileage'),
			'odo_unit' => $this->input->post('odo_unit'),
			'notes' => $this->input->post('notes')
		);
		$this->db->insert('vehicle_stock', $data);
		$insert_id = $this->db->insert_id(); // INSERT INTO vehicle_stock table
		return  $insert_id;
	}


	public function update_vehicle(){

		// UPDATE vehicle_variant table
		$variant_id = $this->input->post('variant_id');

		// Convert dates from dd/mm/yyyy to yyyy-mm-dd
		$model_from =  empty($this->input->post('model_from_f')) ? date_create($this->input->post('year') . "-01-1")->format('Y-m-d') : DateTime::createFromFormat('d/m/Y', $this->input->post('model_from_f'))->format('Y-m-d');
		$model_to =  empty($this->input->post('model_to_f')) ? date_create($this->input->post('year') . "-12-31")->format('Y-m-d') : DateTime::createFromFormat('d/m/Y', $this->input->post('model_to_f'))->format('Y-m-d');

		$data = array(
			'variant' => $this->input->post('variant'),
			'engine_cc' => $this->input->post('engine_cc'),
			'fuel_type_id' => $this->input->post('fuel_type_id'),
			'transmission_type_id' => $this->input->post('transmission_type_id')
		);
		$this->db->where('id', $variant_id);
		$this->db->update('vehicle_variant', $data); // UPDATE vehicle_variant table

		// UPDATE vehicle_stock table
		$id = $this->input->post('id');
		$next_service =  empty($this->input->post('next_service_f')) ? NULL : DateTime::createFromFormat('d/m/Y', $this->input->post('next_service_f'))->format('Y-m-d');
		$nct_due_date =  empty($this->input->post('nct_due_date_f')) ? NULL : DateTime::createFromFormat('d/m/Y', $this->input->post('nct_due_date_f'))->format('Y-m-d');

		$data = array(
			'customer_id' => $this->input->post('customer_id'),
			'make_id' => $this->input->post('make_id'),
			'model_id' => $this->input->post('model_id'),
			'variant_id' => $this->input->post('variant_id'),
			'vin' => strtoupper($this->input->post('vin')),
			'next_service' => $next_service,
			'nct_due_date' => $nct_due_date,
			'year' => $this->input->post('year'),
			'colour_id' => $this->input->post('colour_id'),
			'last_mileage' => $this->input->post('last_mileage'),
			'odo_unit' => $this->input->post('odo_unit'),
			'notes' => $this->input->post('notes'),
			'hidden' => (int)$this->input->post('hidden')
		);
		$this->db->where('id', $this->input->post('id'));
		return $this->db->update('vehicle_stock', $data);
	}


	public function delete_vehicle(){
		$data = array('hidden' => 1);
		$this->db->where('id', $this->input->post('id'));
		return $this->db->update('vehicle_stock', $data);
	}




}