<?php
class Customer_model extends CI_Model{
	public function __construct(){
		$this->load->database();
	}


	public function get_customers($args = Array()){
		// if($limit){
		// 	$this->db->limit($limit, $offset);
		// }
		$this->db->select("
			 customers.id
			,customers.customer_name
			,customers.address
			,customers.address1
			,customers.address2
			,customers.address3
			,customers.county
			,customers.country_id
			,country.country
			,customers.eir_code
			,customers.phone
			,customers.email
			,customers.status
			,customers.created_at
		");
		$this->db->from( 'customers' );
		$this->db->join( 'country', 'customers.country_id = country.id', 'LEFT' );

		// id
		if(array_key_exists("id",$args) && $args['id'] )
			$this->db->where( 'customers.id', $args['id'] );

		// Sort column/index and order
		$sort_index = array_key_exists("sidx",$args) && $args['sidx'] ? $args['sidx'] : 'customers.customer_name';
		$sort_order = array_key_exists("sord",$args) && $args['sord'] ? $args['sord'] : 'ASC';
		$this->db->order_by($sort_index, $sort_order);

		$query = $this->db->get();
		$results_arr = $query->result_array();

		return $results_arr;
	}

	public function get_status(){
		$this->db->distinct();
		$this->db->select( 'customers.status' );
		$this->db->from( 'customers' );
		$this->db->where( 'LENGTH(customers.status) > 0');
		$this->db->order_by('customers.status', 'ASC');
		$query = $this->db->get();
		return $query->result_array();
	}


	public function get_counties(){
		$this->db->select( 'counties.id, counties.county' );
		$this->db->from( 'counties' );
		$this->db->order_by('counties.county', 'ASC');
		$query = $this->db->get();
		return $query->result_array();
	}

	public function get_countries(){
		$this->db->select( 'country.id, country.country' );
		$this->db->from( 'country' );
		$this->db->order_by('country.country', 'ASC');
		$query = $this->db->get();
		return $query->result_array();
	}

	public function create_customer(){
		$new_id = strtoupper(substr($this->input->post('customer_name'), 0, 3)) . rand(100,999);
		$address = $this->input->post('address1');
		$address .= empty($this->input->post('address2')) ? '' : ', ' . $this->input->post('address2');
		$address .= empty($this->input->post('address3')) ? '' : ', ' . $this->input->post('address3');
		$address .= empty($this->input->post('county')) ? '' : ', Co. ' . $this->input->post('county');
		$address .= empty($this->input->post('eir_code')) ? '' : '  ' . $this->input->post('eir_code');

		$data = array(
			'id'=> $new_id,
			'customer_name'=> ucwords($this->input->post('customer_name')),
			'address'=> ucwords($address),
			'address1'=> ucwords($this->input->post('address1')),
			'address2'=> ucwords($this->input->post('address2')),
			'address3'=> ucwords($this->input->post('address3')),
			'county'=> $this->input->post('county'),
			'country_id'=> $this->input->post('country_id'),
			'eir_code'=> strtoupper($this->input->post('eir_code')),
			'phone'=> $this->input->post('phone'),
			'email'=> $this->input->post('email'),
			'status'=> $this->input->post('status')
		);
		$this->db->insert('customers', $data);
		$insert_id = $this->db->insert_id();
		return  $insert_id;
	}

	public function update_customer(){
		$address = $this->input->post('address1');
		$address .= empty($this->input->post('address2')) ? '' : ', ' . $this->input->post('address2');
		$address .= empty($this->input->post('address3')) ? '' : ', ' . $this->input->post('address3');
		$address .= empty($this->input->post('county')) ? '' : ', Co. ' . $this->input->post('county');
		$address .= empty($this->input->post('eir_code')) ? '' : ' ' . $this->input->post('eir_code');

		$data = array(
			'customer_name'=> ucwords($this->input->post('customer_name')),
			'address'=> ucwords($address),
			'address1'=> ucwords($this->input->post('address1')),
			'address2'=> ucwords($this->input->post('address2')),
			'address3'=> ucwords($this->input->post('address3')),
			'county'=> $this->input->post('county'),
			'country_id'=> $this->input->post('country_id'),
			'eir_code'=> strtoupper($this->input->post('eir_code')),
			'phone'=> $this->input->post('phone'),
			'email'=> $this->input->post('email'),
			'status'=> $this->input->post('status')
		);
		$this->db->where('id', $this->input->post('id'));
		return $this->db->update('customers', $data);
	}

	public function delete_customer(){
		$this->db->where('id', $this->input->post('id'));
		return $this->db->delete('customers');
	}

}