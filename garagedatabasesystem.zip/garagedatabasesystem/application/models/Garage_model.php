<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
ob_start();
class Garage_model extends CI_Model {
    public $roles;
    function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->helper(array('form', 'url'));
        $this->roles = $this->config->item('roles');
    }
    public function validate_username() {
        $username = $this->input->post('user_name');
        $sql = "SELECT * FROM admin WHERE user_name = ?";
        $query = $this->db->query($sql, array($username));
        return ($query->num_rows() == 1) ? true : false;
    }


    /** Manage Users Data **/
    public function insertInvoice($data) {
        $order_total = 0;
        $balance = 0;
        $time = time();
        $data1 = array('order_id' => trim($data["order_id"]), 'order_date' => trim($data["order_date"]), 'order_receiver_name' => trim($data["order_receiver_name"]), 'order_receiver_addr' => trim($data["order_receiver_address"]), 'order_total' => $order_total, 'balance' => $balance, 'paid' => trim($data["order_amt_received"]), 'order_receiver_phone' => trim($data["phone"]), 'order_datetime' => date("d-m-Y H:i:s", $time));
        $q = $this->db->insert_string('invoices_test', $data1);
        $this->db->query($q);
        $order_id = $this->db->insert_id();
        for ($count = 0;$count < $_POST["total_item"];$count++) {
            $order_total = $order_total + floatval(trim($data["order_item_actual_amount"][$count]));
            $balance = $order_total - floatval(trim($data["order_amt_received"]));
            $data2 = array('order_id' => $order_id, 'item_name' => trim($data["item_name"][$count]), 'order_description' => trim($data["description"][$count]), 'order_category' => trim($data["category"][$count]), 'order_item_quantity' => trim($data["order_item_quantity"][$count]), 'order_item_price' => trim($data["order_item_price"][$count]), 'order_item_actual_amount' => trim($data["order_item_actual_amount"][$count]));
            $q2 = $this->db->insert_string('invoice_order_item', $data2);
            $this->db->query($q2);
        }
        $data3 = array('order_total' => $order_total, 'balance' => $balance, 'order_id' => $order_id);
        $this->db->where('order_id', $order_id);
        $this->db->update('invoices_test', $data3);
    }
    function update_invoice($invoice_id) {
        $order_total = 0;
        $this->db->where('order_id', $invoice_id);
        $this->db->delete('invoice_order_item');
        for ($count = 0;$count < $_POST["total_item"];$count++) {
            $order_total = $order_total + floatval(trim($_POST["order_item_actual_amount"][$count]));
            $balance = $order_total - floatval(trim($_POST["order_amt_received"]));
            $data1 = array('order_id' => $invoice_id, 'item_name' => trim($_POST["item_name"][$count]), 'order_description' => trim($_POST["description"][$count]), 'order_category' => trim($_POST["category"][$count]), 'order_item_quantity' => trim($_POST["order_item_quantity"][$count]), 'order_item_price' => trim($_POST["order_item_price"][$count]), 'order_item_actual_amount' => trim($_POST["order_item_actual_amount"][$count]));
            $q2 = $this->db->insert_string('invoice_order_item', $data1);
            $this->db->query($q2);
        }
        $data2 = array('order_id' => trim($_POST["order_id"]), 'order_date' => trim($_POST["order_date"]), 'order_receiver_name' => trim($_POST["order_receiver_name"]), 'order_receiver_addr' => trim($_POST["order_receiver_address"]), 'order_total' => $order_total, 'balance' => $balance, 'paid' => trim($_POST["order_amt_received"]), 'order_receiver_phone' => trim($_POST["phone"]), 'order_id' => $invoice_id);
        $this->db->where('order_id', $invoice_id);
        $this->db->update('invoices_test', $data2);
    }
    function delete_invoice($order_id) {
        $this->db->where('order_id', $order_id);
        $this->db->delete('invoices_test');
        $this->db->where('order_id', $order_id);
        $this->db->delete('invoice_order_item');
    }

    /** Manage STOCK Data **/

    function insert_stock($data) {
        $get_data = array('description' => $this->input->post('description'), 'category' => $this->input->post('category'), 'unit_price' => $this->input->post('unit_price'),'make' => $this->input->post('make'),'current_stock' => $this->input->post('current_stock'),'part_no' => $this->input->post('part_no'), 'model' => $this->input->post('model'));
        $this->db->insert('invoice_stock_item', $get_data);
    }
    function update_stock($rate_id) {
        $data = array('description' => $this->input->post('description'), 'category' => $this->input->post('category'), 'current_stock' => $this->input->post('current_stock'), 'unit_price' => $this->input->post('unit_price'));
        $this->db->where('rate_id', $rate_id);
        $this->db->update('invoice_stock_item', $data);
    }
    function delete_stock($rate_id) {
        $this->db->where('rate_id', $rate_id);
        $this->db->delete('invoice_stock_item');
	}

    /** Manage VEHICLE Data **/

    function insert_vehicle($data) {
        $get_data = array('vehiclereg' => $this->input->post('vehiclereg'), 'customer' => $this->input->post('customer'), 'yearofmanufacture' => $this->input->post('yearofmanufacture'),'makemodel' => $this->input->post('makemodel'),'colour' => $this->input->post('colour'),'lastmileage' => $this->input->post('lastmileage'),'fuel' => $this->input->post('fuel'), 'vin' => $this->input->post('vin'),'cc' => $this->input->post('cc'));
        $this->db->insert('garage_vehicles', $get_data);
    }
    function update_vehicle($id) {
        $data = array('customer' => $this->input->post('customer'), 'nextservicedue' => $this->input->post('nextservicedue'), 'lastmileage' => $this->input->post('lastmileage'), 'makemodel' => $this->input->post('makemodel'),'vehiclereg' => $this->input->post('vehiclereg'),'notes' => $this->input->post('notes'));
        $this->db->where('id', $id);
        $this->db->update('garage_vehicles', $data);
    }
    function delete_vehicle($id) {
        $this->db->where('id', $id);
        $this->db->delete('garage_vehicles');
    }

    /** Manage STAFF Data **/

    function insert_staff($data) {
        $get_data = array('name' => $_POST['staff_name'], 'user_name' => $_POST['staff_username'], 'email' => $_POST['staff_email'], 'role' => $_POST['staff_role'], 'password' => sha1($this->input->post('password')));
        $db = $this->db->insert_string('admin', $get_data);
        $this->db->query($db);
    }
    function update_staff($id) {
        $data['name'] = $this->input->post('staff_name');
        $data['user_name'] = $this->input->post('staff_username');
        $data['email'] = $this->input->post('staff_email');
        $data['role'] = $this->input->post('staff_role');
        $data['password'] = sha1($this->input->post('password'));
        $this->db->where('admin_id', $id);
        $this->db->update('admin', $data);
    }
    function delete_staff($id) {
        $this->db->where('admin_id', $id);
        $this->db->delete('admin');
    }

    /** Manage CUSTOMER Data **/

    function select_customer_info() {
        return $this->db->get('customers')->result_array();
    }
    function insert_customer($data) {
        $get_data = array('id' => trim($_POST['id']), 'customer_name' => trim($_POST['customer_name']), 'address' => trim($_POST['customer_address']), 'phone' => trim($_POST['customer_phone']), 'status' => trim($_POST['status']),);
        $db = $this->db->insert_string('customers', $get_data);
        $this->db->query($db);
    }
    function update_customer($id) {
        $data['customer_name'] = $this->input->post('customer_name');
        $data['address'] = $this->input->post('customer_address');
        $data['phone'] = $this->input->post('customer_phone');
        $data['status'] = $this->input->post('status');
        $this->db->where('id', $id);
        $this->db->update('customers', $data);
    }
    function delete_customer($id) {
        $this->db->where('id', $id);
        $this->db->delete('customers');
    }

    /** Manage SUPPLIER Data **/

    function select_supplier_info() {
        return $this->db->get('suppliers')->result_array();
    }
    function insert_supplier($data) {
        $get_data = array('id' => trim($_POST['id']), 'supplier_name' => trim($_POST['supplier_name']), 'address' => trim($_POST['customer_address']), 'phone' => trim($_POST['supplier_phone']), 'status' => trim($_POST['status']),);
        $db = $this->db->insert_string('suppliers', $get_data);
        $this->db->query($db);
    }
    function update_supplier($id) {
        $data['supplier_name'] = $this->input->post('supplier_name');
        $data['address'] = $this->input->post('supplier_address');
        $data['phone'] = $this->input->post('supplier_phone');
        $data['status'] = $this->input->post('status');
        $this->db->where('id', $id);
        $this->db->update('suppliers', $data);
    }
    function delete_supplier($id) {
        $this->db->where('id', $id);
        $this->db->delete('suppliers');
    }

    /** Manage DEBTOR Data **/

    function insert_record($data) {
        $get_debt = array('customer_name' => trim($_POST['order_receiver_name']), 'amount_paid' => trim($_POST['amount_paid']), 'balance' => trim($_POST['balance']), 'date_received' => trim($_POST['date']), 'order_id' => trim($_POST['order_id']),'order_total' => trim($_POST['order_total']),);
        $db = $this->db->insert_string('record_debt', $get_debt);
        $this->db->query($db);
    }
    function update_debt($id) {
        $data['customer_name'] = $this->input->post('customer_name');
        $data['amount_paid'] = $this->input->post('paid');
        $data['balance'] = $this->input->post('balance');
        // $balance = $order_total - floatval(trim($_POST["amount_paid"]));
        $this->db->where('id', $id);
        $this->db->update('record_debt', $data);
    }
    function delete_debt($id) {
        $this->db->where('id', $id);
        $this->db->delete('record_debt');
    }
    function get_categories() {
        $this->db->order_by('title');
        $query = $this->db->get('invoice_job_category');
        return $query->result_array();
    }
    function get_status() {
        $this->db->order_by('title');
        $query = $this->db->get('customer_status');
        return $query->result_array();
    }

    // ////////IMAGE URL//////////
    // function get_image_url($type = '', $id = '') {
    //     if (file_exists('uploads/' . $type . '_image/' . $id . '.jpg'))
    //         $image_url = base_url() . 'uploads/' . $type . '_image/' . $id . '.jpg';
    //     else
    //         $image_url = base_url() . 'uploads/user.jpg';
    //     return $image_url;
    // }
    

    /** Manage SYSTEM Data **/
    function update_system_settings() {
        $data['description'] = $this->input->post('system_name');
        $this->db->where('type', 'system_name');
        $this->db->update('settings', $data);
        $data['description'] = $this->input->post('system_title');
        $this->db->where('type', 'system_title');
        $this->db->update('settings', $data);
        $data['description'] = $this->input->post('address');
        $this->db->where('type', 'address');
        $this->db->update('settings', $data);
        $data['description'] = $this->input->post('phone');
        $this->db->where('type', 'phone');
        $this->db->update('settings', $data);
        $data['description'] = $this->input->post('system_email');
        $this->db->where('type', 'system_email');
        $this->db->update('settings', $data);
        $data['description'] = $this->input->post('language');
        $this->db->where('type', 'language');
        $this->db->update('settings', $data);
        $data['description'] = $this->input->post('company');
        $this->db->where('type', 'company');
        $this->db->update('settings', $data);
        // $logo_id  =   $this->db->insert_id();
        // move_uploaded_file($_FILES["logo"]["tmp_name"], "uploads/company/" . $logo_id . '.jpg');
        
    }
}
ob_end_flush();
