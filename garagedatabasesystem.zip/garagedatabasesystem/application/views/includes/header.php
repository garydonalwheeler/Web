<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
	<meta name="description" content="Web Based Garage Invoice Management System" />
	<meta name="Keywords" content="garage, repair, automotive, parts, 4x4">
	<meta name="author" content="GARY WHEELER" />
	<?php if(isset($title)) : ?>
		<title><?= $title ?> | Garage Database System</title>
	<?php else : ?>
		<title>Garage Database System</title>
	<?php endif; ?>

	<link type="text/css" rel="shortcut icon" href="<?php echo base_url('assets/img/home-16.png')?>">
	<link type="text/css" rel="stylesheet" href="<?php echo base_url('assets/css/animate.min.css')?>">
	<link type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">

	<!-- Page level plugin CSS-->
	<link type="text/css" href="<?php echo base_url('assets/css/dataTables.bootstrap4.css')?>" rel="stylesheet">
	<!-- Custom fonts for this template-->
	<link type="text/css" href="<?php echo base_url('assets/css/font-awesome.min.css')?>" rel="stylesheet">

<link type="text/css" href="<?php echo base_url ('assets/css/jquery-ui.css');?>" rel="stylesheet">

	<link type="text/css" href="<?php echo base_url('assets/css/jquery.dataTables.min.css')?>">
	<link type="text/css" href="<?php echo base_url('assets/css/buttons.dataTables.min.css')?>" rel="stylesheet">
	<!-- Custom styles for this template-->
	<link type="text/css" href="<?php echo base_url('assets/css/sb-admin.css')?>" rel="stylesheet">
	<link type="text/css" href="<?php echo base_url('assets/css/metisMenu.min.css')?>" rel="stylesheet">

	 <!-- CONTENT-WRAPPER SECTION END-->



	<script src="<?php echo base_url('assets/js/jquery.min.js')?>"></script>
<script src="<?php echo base_url('assets/js/jquery-ui.js'); ?>"></script>

	<script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
	<script src="<?php echo base_url('assets/js/bootstrap.bundle.min.js')?>"></script>
	<!-- Core plugin JavaScript-->
	<script src="<?php echo base_url('assets/js/jquery.dataTables.min.js')?>"></script>
	<!-- Page level plugin CSS-->
	<script src="<?php echo base_url('assets/js/dataTables.bootstrap4.js')?>"></script>
	<script src="<?php echo base_url('assets/js/sb-admin.min.js')?>"></script>
	<!-- Metis Menu Plugin JavaScript -->
	<script src="<?php echo base_url('assets/js/metisMenu.min.js')?>"></script>
	<!-- Custom Theme JavaScript -->
	<script src="<?php echo base_url('assets/js/dataTables.buttons.min.js')?>"></script>
	<script src="<?php echo base_url('assets/js/buttons.flash.min.js')?>"></script>
	<script src="<?php echo base_url('assets/js/jszip.min.js')?>"></script>
	<script src="<?php echo base_url('assets/js/pdfmake.min.js')?>"></script>
	<script src="<?php echo base_url('assets/js/vfs_fonts.js')?>"></script>
	<script src="<?php echo base_url('assets/js/buttons.html5.min.js')?>"></script>
	<script src="<?php echo base_url('assets/js/buttons.print.min.js')?>"></script>
	<script src="<?php echo base_url('assets/js/script.js')?>"></script>

	<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
	<script type= "text/javascript" src= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
	<link rel= "stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

	<style>
		* {
			margin: 0;
			padding: 0;
			-webkit-font-smoothing: antialiased;
			-webkit-text-shadow: rgba(0, 0, 0, .01) 0 0 1px;
			text-shadow: rgba(0, 0, 0, .1) 0 0 1px;
			box-sizing: border-box;
		 }
		 body {
			font-family: 'Open Sans', sans-serif;
			font-weight: 400 !important;
			font-size: 14px !important;
		 }
		 label {
			font-weight: 500;
			font-size: 14px;
		 }
		 .fa-edit {
			color:#fff;
		 }
	  </style>
</head>

<body id="page-top">
	<!-- Navigation -->
	<nav class="navbar navbar-expand navbar-dark bg-dark static-top">
		<a class="navbar-brand mr-1" href="<?= base_url ('/admin/dashboard') ?>">Garage Database System</a>
		<button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
			<i class="fa fa-bars"></i>
		</button>
		<!-- Navbar -->
		<ul class="navbar-nav ml-auto mr-0 mr-md-3 my-2 my-md-0">
			<li class="nav-item dropdown no-arrow">
				<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<i class="fa fa-user fa-fw"></i>
				</a>
				<div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
					<div class="dropdown-divider"></div>
					<a href="<?= base_url ('/account/logout') ?>" style="margin-left:5px;text-decoration:none;"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
				</div>
			</li>
		</ul>

	</nav>
	<div id="wrapper">
		<!-- Sidebar -->
		<ul class="sidebar navbar-nav">
			<?php
			/*How can I set class=“active” to navigation menu in codeigniter?
			https://stackoverflow.com/questions/30367084/how-can-i-set-class-active-to-navigation-menu-in-codeigniter
			https://selftaughtcoders.com/displaying-data-codeigniter-view/
			$current_page = $this->uri->uri_string();*/
			$current_page = $this->uri->segment(1);
			?>

			<li class="nav-item <?php if($current_page=="dashboard"){echo 'active';}?>">
				<a class="nav-link" href="<?php  echo base_url ('/admin/dashboard') ?>">
					<i class="fa fa-desktop"></i> <span>Dashboard</span></a>
			</li>

			<!-- INVOICE SUMMARY -->
			<li class="nav-item <?php if($current_page=="sales"){echo 'active';}?>">
				<a class="nav-link" href="<?php  echo base_url ('/admin/sales') ?>">
					<i class="fa fa-tasks"></i> <span>Invoice Summary</span></a>
			</li>

			<!-- MANAGE INVOICES -->
			<li class="nav-item <?php if($current_page=="invoice"){echo 'active';}?>">
				<a class="nav-link" href="<?php  echo base_url ('/admin/invoice') ?>">
					<i class="fa fa-envelope"></i> <span>Manage Invoices</span></a>
			</li>

			<!-- MANAGE STOCK -->
			<li class="nav-item <?php if($current_page=="stock"){echo 'active';}?>">
				<a class="nav-link" href="<?php  echo base_url ('/admin/stock') ?>">
					<i class="fa fa-pencil"></i> <span>Manage Stock</span></a>
			</li>

			<!-- CUSTOMERS -->
			<li class="nav-item  <?php if($current_page=="customers"){echo 'active';}?>">
				<a class="nav-link" href="<?php  echo base_url ('/customers') ?>">
					<i class="fa fa-users"></i> <span>Manage Customers</span></a>
			</li>

			<!-- DEBTORS -->
			<li class="nav-item  <?php if($current_page=="customer_record_debt"){echo 'active';}?>">
				<a class="nav-link" href="<?php  echo base_url ('/admin/customer_record_debt') ?>">
					<i class="fas fa-fw fa fa-list"></i> <span>Manage Debtors</span></a>
			</li>

			<!-- SUPPLIERS -->
			<li class="nav-item  <?php if($current_page=="supplier"){echo 'active';}?>">
				<a class="nav-link" href="<?php  echo base_url ('/admin/supplier') ?>">
					<i class="fas fa-fw fa fa-shopping-cart"></i> <span>Manage Suppliers</span></a>
			</li>

			<!-- VEHICLES -->
			<li class="nav-item  <?php if($current_page=="vehicles"){echo 'active';}?>">
				<a class="nav-link" href="<?php  echo base_url ('/vehicles') ?>">
					<i class="fas fa-fw fa fa-truck"></i> <span>Manage Vehicles</span></a>
			</li>

			<!-- USER ACCOUNT -->
			<li class="nav-item  <?php if($current_page=="profile"){echo 'active';}?>">
				<a class="nav-link" href="<?php  echo base_url ('/admin/profile') ?>">
					<i class="fas fa-fw fa fa-user"></i> <span>Staff Profile</span></a>
			</li>

			<!-- SETTINGS -->
			<li class="nav-item  <?php if($current_page=="settings"){echo 'active';}?>">
				<a class="nav-link" href="<?php  echo base_url ('/admin/settings') ?>">
					<i class="fa fa-gears"></i>&nbsp;<span>System Settings</span></a>
			</li>

		</ul> <!-- Dashboard -->

		<div id="content-wrapper">

			<div class="text-center js-message" style="margin-top:-1rem;display:none">
				<p class="alert alert-success m-0">Message</p>
			</div>

			<?php if($this->session->flashdata('vehicle_created')): ?>
				<div class="text-center" style="margin-top:-1rem">
					<?php echo '<p class="alert alert-success m-0">'.$this->session->flashdata('vehicle_created').'</p>'; ?>
				</div>
			<?php endif; ?>

			<?php if($this->session->flashdata('vehicle_updated')): ?>
				<div class="text-center" style="margin-top:-1rem">
					<?php echo '<p class="alert alert-success m-0">'.$this->session->flashdata('vehicle_updated').'</p>'; ?>
				</div>
			<?php endif; ?>

			<?php if($this->session->flashdata('vehicle_restored')): ?>
				<div class="text-center" style="margin-top:-1rem">
					<?php echo '<p class="alert alert-success m-0">'.$this->session->flashdata('vehicle_restored').'</p>'; ?>
				</div>
			<?php endif; ?>

			<?php if($this->session->flashdata('vehicle_deleted')): ?>
				<div class="text-center" style="margin-top:-1rem">
					<?php echo '<p class="alert alert-success m-0">'.$this->session->flashdata('vehicle_deleted').'</p>'; ?>
				</div>
			<?php endif; ?>

			<?php if($this->session->flashdata('no_record')): ?>
				<div class="text-center" style="margin-top:-1rem">
					<?php echo '<p class="alert alert-success m-0">'.$this->session->flashdata('no_record').'</p>'; ?>
				</div>
			<?php endif; ?>

			<!-- Customer Messages -->
			<?php if($this->session->flashdata('customer_updated')): ?>
				<div class="text-center" style="margin-top:-1rem">
					<?php echo '<p class="alert alert-success m-0">'.$this->session->flashdata('customer_updated').'</p>'; ?>
				</div>
			<?php endif; ?>

			<?php if($this->session->flashdata('customer_created')): ?>
				<div class="text-center" style="margin-top:-1rem">
					<?php echo '<p class="alert alert-success m-0">'.$this->session->flashdata('customer_created').'</p>'; ?>
				</div>
			<?php endif; ?>

			<?php if($this->session->flashdata('customer_deleted')): ?>
				<div class="text-center" style="margin-top:-1rem">
					<?php echo '<p class="alert alert-success m-0">'.$this->session->flashdata('customer_deleted').'</p>'; ?>
				</div>
			<?php endif; ?>

			<div class="container-fluid">
