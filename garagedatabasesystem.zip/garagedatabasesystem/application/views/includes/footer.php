				</div>
				<!-- Sticky Footer -->
				<footer class="sticky-footer">
					<div class="container my-auto">
						<div class="copyright text-center my-auto">
							<p>Copyright &copy; 2021 WEST END MOTORS LIMITED</p>
						</div>
					</div>
				</footer>
			</div>
			<!-- End Content-Wrapper  -->
		</div>
		<!-- End Wrapper  -->
		<!-- Scroll to Top Button-->
		<a class="scroll-to-top rounded" href="#">
			<i class="fa fa-arrow-up" aria-hidden="true"></i>
		</a>

		<!-- (Ajax Modal)-->
		<div class="modal fade" id="modal_ajax" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="exampleModalLabel"></h4>
						<button class="close" type="button" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">×</span>
						</button>
					</div>
					<div class="modal-body">
					</div>
					<div class="modal-footer">
						West End Motors Ltd
					</div>
				</div>
			</div>
		</div>
	</body>

</html>

<?php
/*
<script src="<?php echo base_url('assets/css/datepicker.css')?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap-datepicker.js')?>"></script>
*/
 ?>

<script type="text/javascript">

	function showAjaxModal(url) {
		// SHOWING AJAX PRELOADER IMAGE
		jQuery('#modal_ajax .modal-body').html('<div style="text-align:center;margin-top:200px;"><img src="assets/img/preloader.gif" style="height:25px;" /></div>');

		// LOADING THE AJAX MODAL
		jQuery('#modal_ajax').modal('show', { backdrop: 'true' });

		// SHOW AJAX RESPONSE ON REQUEST SUCCESS
		$.ajax({
			url: url,
			success: function(response) {
				jQuery('#modal_ajax .modal-body').html(response);
			}
		});
	}

	function isNumbers(evt, element) {
		var charCode = (evt.which) ? evt.which : event.keyCode;
		if (
			(charCode != 46 || $(element).val().indexOf('.') != -1) && // “.” CHECK DOT, AND ONLY ONE.
			(charCode < 48 || charCode > 57))
			return false;
		return true;
	}



	$(document).ready(function() {
		//Date Object
		$('.datepicker').datepicker({
			// format: "yyyy-mm-dd",
			format: "dd/mm/yyyy",
			autoclose: true
		});
		// $('#order_date').datepicker({
		// 	format: "yyyy-mm-dd",
		// 	autoclose: true
		// });

		//DataTable
		$('#data-table').DataTable({
			dom: 'Bfrtip',
			buttons: [
				'copy', 'csv', 'excel', 'pdf', 'print'
			],
			"pageLength": 25
		});

		// scroll body to 0px on click
		$('.scroll-to-top').click(function() {
			$('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});

		//Validation on key press
		$('.number_only').keypress(function(e) {
			return isNumbers(e, this);
		});
	});

</script>