
<div class="row">
	<div class="col-md-12" style="margin-top:15px; font-size:16px;">
	</div>
</div>

<div class="row">
	<div class="col-lg-12">
		<h2 class="page-header"><?= $title ?></h2>
	</div>
	<!-- /.col-lg-12 -->
</div>

<div class="container-fluid table-responsive">
	<h4 align="center" class="animated fadeInDown">West End Motors Ltd</h4>
	<br />
	<b>MANAGE VEHICLE INFORMATION</b>
	<br />
	<div align="right">
		<a href="<?= site_url('/vehicles/0') ?>" class="btn btn-primary btn-md">CREATE</a>
	</div>
	<br />
	<table id="data-table" class="table table-bordered table-striped animated fadeInUp" width="100%" cellspacing="0">
		<thead>
			<tr>
				<th>No.</th>
				<th>Vehicle Registration</th>
				<th>Make and Model</th>
				<th>Engine CC</th>
				<th>VIN</th>
				<th>Colour</th>
				<th>Fuel Type</th>
				<th>A/C No.</th>
				<th>Show</th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>
		</thead>

		<?php $index = 0; ?>

		<?php foreach($stock as $item): ?>
			<?php $index++; ?>

			<tr id="<?= $item['id'] ?>">
				<?php /* <td><?= $item['id'] ?></td> */?>
				<td class="idx"><?= $index ?></td>
				<td><?= $item['number_plate'] ?></td>
				<td><?= $item['make'] . ' ' . $item['model'] ?></td>
				<td><?= $item['engine_cc'] ?></td>
				<td><?= $item['vin'] ?></td>
				<td><?= $item['colour'] ?></td>
				<td><?= $item['fuel'] ?></td>
				<td><?= $item['customer_id'] ?></td>
				<td class="text-center">
					<a href="#" class="show-vehicle btn btn-info btn-sm"
						data-id="<?= $item['id'] ?>"
						data-vehiclereg="<?= $item['number_plate'] ?>"
						data-customer="<?= $item['customer_id'] ?>"
						data-makemodel="<?= $item['make'] . ' ' . $item['model'] ?>"
						data-colour="<?= $item['colour'] ?>"
						data-fuel="<?= $item['fuel'] ?>"
						data-lastmileage="<?= $item['last_mileage'] ?>"
						data-nextservicedue="<?= $item['next_service'] ?>"
						data-notes="<?= $item['notes'] ?>"
						data-vin="<?= $item['vin'] ?>">
						<i class="fa fa-eye"></i>
					</a>
				</td>
				<td class="text-center">
					<?php /* <!-- <a onclick="showAjaxModal('http://localhost/garagedatabasesystem/modal/popup/update_vehicle/1');" class="edit-vehicle btn btn-success btn-sm"> --> */?>
					<a href="<?php echo site_url('/vehicles/'.$item['id']); ?>" class="edit-vehicle btn btn-success btn-sm">
						<i class="fa fa-edit"></i>
					</a>
				</td>
				<td><a href="#" data-id="<?= $item['id'] ?>" data-vehiclereg="<?= $item['number_plate'] ?>" class="delete-vehicle btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a></td>
			</tr>
		<?php endforeach; ?>

	</table>
</div>
<br>


<!-- Modal Form -->
<div id="show-vehicle" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="exampleModalLabel"></h4>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label class="control-label col-md-4" for="">ID:</label>
					<b id="s-id"></b>
				</div>
				<div class="form-group">
					<label class="control-label col-md-4" for="">Vehicle Reg:</label>
					<b id="s-vehiclereg"></b>
				</div>
				<div class="form-group">
					<label class="control-label col-md-4" for="">Make & Model:</label>
					<b id="s-makemodel"></b>
				</div>
				<div class="form-group">
					<label class="control-label col-md-4" for="">Colour:</label>
					<b id="s-colour"></b>
				</div>
				<div class="form-group">
					<label class="control-label col-md-4" for="">Fuel:</label>
					<b id="s-fuel"></b>
				</div>
				<div class="form-group">
					<label class="control-label col-md-4" for="">Next Service Due:</label>
					<b id="s-nextservicedue"></b>
				</div>
				<div class="form-group">
					<label class="control-label col-md-4" for="">Last Mileage:</label>
					<b id="s-lastmileage"></b>
				</div>
				<div class="form-group">
					<label class="control-label col-md-4" for="">Customer:</label>
					<b id="s-customer"></b>
				</div>
				<div class="form-group">
					<label class="control-label col-md-4" for="">Notes:</label><br />
					<b id="s-notes"></b>
				</div>
			</div>
			<div class="modal-footer">
				West End Motors Ltd
			</div>
		</div>
	</div>
</div>




<script type="application/javascript">

var baseUrl = "<?= site_url() ?>";

$(document).ready(function() {

	//Delete Content
	$(document).on('click', '.delete-vehicle', function() {
		event.preventDefault();
		var item_id = $(this).data("id");
		var item_desc = $(this).data("vehiclereg");
		var delete_url = baseUrl + 'vehicles/delete';
		delete_item(delete_url, item_id, item_desc);
	});

	//Show Modal for Vehicle
	$(document).on('click', '.show-vehicle',
		function() {
			$('#show-vehicle').modal('show');
			$('#s-id').text($(this).data('id'));
			$('#s-vehiclereg').text($(this).data('vehiclereg'));
			$('#s-customer').text($(this).data('customer'));
			$('#s-makemodel').text($(this).data('makemodel'));
			$('#s-colour').text($(this).data('colour'));
			$('#s-fuel').text($(this).data('fuel'));
			$('#s-lastmileage').text($(this).data('lastmileage'));
			$('#s-nextservicedue').text($(this).data('nextservicedue'));
			$('#s-vin').text($(this).data('vin'));
			$('#s-notes').text($(this).data('notes'));
			$('.modal-title').text('Vehicle Information');
		});

	//Call to the form-modal
	$(document).on('click', '.create-price',
		function() {
			$('#create').modal('show');
			$('.form-horizontal').show();
			$('.modal-title').text('Enter New Vehicle Data');
	});
});

</script>
