
<div class="row">
	<div class="col-md-12" style="margin-top:15px; font-size:16px;">
	</div>
</div>

<div class="row">
	<div class="col-xl-10 mb-3">
		<h2 class="page-header"><?= $title ?></h2>
	</div>
</div>

<div class="row">
	<div class="col-sm-12 px-5">
		<?php echo validation_errors(); ?>
		<?php $form_action_url = $vehicle_id == 0 ? 'vehicles/create' : 'vehicles/update'?>

		<?php echo form_open($form_action_url, array('id' => 'vehicle_form')); ?>
			<input readonly type="hidden" name="id" value="<?= $vehicle_id ?>">
			<input readonly type="hidden" name="hidden" value="0">
			<div class="row">
				<div class="col-sm-12 mt-4">
					<h5>Vehicle Details</h5>
					<hr class="mt-0 mb-2">
				</div>
			</div>

			<fieldset class="form-group border pt-2 pb-4 px-5 col-sm-12 mt-1 mb-3" style="background: #fafafa">
				<div class="form-group row my-0  align-items-center">
					<label class="col-sm-3 col-lg-2 col-xl-2 mt-3 col-form-label" for="number_plate">Registration:</label>
					<div class="col-sm-6 col-lg-4 col-xl-3 mt-3 ">
						<?php $reg_no = isset($stock_item['number_plate']) ? $stock_item['number_plate'] : ''?>
						<input type="text" list="plate_suggestions" class="form-control px-3" id="number_plate" name="number_plate" placeholder="Registration" value="<?= $reg_no ?>">
						<datalist id="plate_suggestions">
							<?php if($vehicle_id == 0) : ?>
								<?php foreach($deleted_vehicles as $deleted_vehicle): ?>
									<option value="<?= $deleted_vehicle['number_plate'] ?>"></option>
								<?php endforeach; ?>
							<?php endif; ?>
						</datalist>
					</div>

					<div class="col-sm-3 col-lg-6 col-xl-2 mt-3 ">
						<button id="get-data" type="button" class="btn btn-secondary mx-0 px-3  btn-sm">Get vehicle info</button>
					</div>

					<label class="col-sm-3 col-lg-2 col-xl-2 mt-3 col-form-label" for="customer_id">Customer:</label>
					<div class="col-sm-9 col-lg-4  col-xl-3 mt-3">
						<select class="form-control custom-select" id="customer_id" name="customer_id">
							<option value="">Select Customer</option>
							<?php foreach($customers as $customer): ?>
								<?php $selected =  isset($stock_item['customer_id']) && $customer['id'] == $stock_item['customer_id'] ? 'selected' : '';?>
								<option value="<?= $customer['id'] ?>" <?= $selected ?>><?= $customer['customer_name'] ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>

				<div class="form-group row  my-0 align-items-center">
					<label class="col-sm-3 col-lg-2 col-xl-2 mt-3 col-form-label" for="last_mileage">Mileage:</label>
					<div class="col-sm-6 col-lg-4 col-xl-3 mt-3 ">
						<?php $mileage = isset($stock_item['last_mileage']) && isset($stock_item['last_mileage']) ? $stock_item['last_mileage'] : ''?>
						<input type="number" class="form-control pl-3" id="last_mileage" name="last_mileage" placeholder="Mileage" value="<?= $mileage ?>">
					</div>
					<div class="col-sm-3 col-lg-6 col-xl-2 mt-3 ">
						<?php $mi_checked = (isset($stock_item['odo_unit']) &&  $stock_item['odo_unit'] == 'm')  ? 'checked' : '';?>
						<div class="custom-control custom-radio custom-control-inline">
						  <input type="radio" class="custom-control-input" id="odo_m" name="odo_unit" value="m" <?= $mi_checked ?>>
						  <label class="custom-control-label" for="odo_m">Miles<span class="d-none d-lg-inline"></span></label>
						</div>
						<?php $km_checked = (isset($stock_item['odo_unit']) &&  $stock_item['odo_unit'] == 'k')  ? 'checked' : '';?>
						<div class="custom-control custom-radio custom-control-inline">
						  <input type="radio" class="custom-control-input" id="odo_k" name="odo_unit" value="k" <?= $km_checked ?>>
						  <label class="custom-control-label" for="odo_k">Km</span></label>
						</div>
					</div>

					<label class="col-sm-3 col-lg-2 col-xl-2 mt-3 col-form-label" for="vin">VIN:</label>
					<div class="col-sm-9 col-lg-4 col-xl-3 mt-3 ">
						<?php $vin = isset($stock_item['vin']) ? $stock_item['vin'] : ''?>
						<input type="text" class="form-control px-3" id="vin" name="vin" placeholder="VIN" value="<?= $vin ?>">
					</div>
				</div>
			</fieldset>

			<div class="row">
				<div class="col-sm-12 mt-3">
					<h5>Model Specifications</h5>
					<hr class="mt-0 mb-2">
				</div>
			</div>

			<fieldset class="form-group border pt-2 pb-4 px-5 col-sm-12  mt-1 mb-3" style="background: #fafafa">
				<div class="form-group row my-0">
					<label for="make_id" class="col-sm-3 col-lg-2 col-xl-2 mt-3 col-form-label">Make</label>
					<div class="col-sm-9 col-lg-4 col-xl-3 mt-3">
						<select class="form-control custom-select" id="make_id" name="make_id">
							<option value="">Select Make</option>
							<?php foreach($makes as $make): ?>
								<?php $selected = isset($stock_item['make_id']) && $make['id'] == $stock_item['make_id'] ? 'selected' : '';?>
								<option value="<?= $make['id'] ?>" data-mgmakeid="<?= $make['mg_make_id'] ?>" <?= $selected ?>><?= $make['make'] ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<label for="model_id" class="col-sm-3 col-lg-2 col-xl-2 mt-3 offset-xl-2 col-form-label">Model:</label>
					<div class="col-sm-9 col-lg-4  col-xl-3 mt-3">
						<select class="form-control custom-select" id="model_id" name="model_id">
							<option value="">Select Model</option>
							<?php if(isset($models)) : ?>
								<?php foreach($models as $model): ?>
								<?php $selected = isset($stock_item['model_id']) && $model['id'] == $stock_item['model_id'] ? 'selected' : '';?>
									<option value="<?= $model['id'] ?>" data-mgmodelid="<?= $model['mg_model_id'] ?>" <?= $selected ?>><?= $model['model'] ?></option>
								<?php endforeach; ?>
							<?php endif; ?>

						</select>
					</div>
				</div>

				<div class="form-group row my-0">
					<label for="variant" class="col-sm-3 col-lg-2 col-xl-2 mt-3 col-form-label">Variant:</label>
					<div class="col-sm-9 col-lg-4 col-xl-3 mt-3">
						<?php $variant = isset($stock_item['variant']) ? $stock_item['variant'] : ''?>

						<!-- Hidden inputs -->
						<input type="hidden" name="variant_id" id="variant_id" value="<?= $variant_id ?>">
						<input type="hidden" name="mg_car_id" id="mg_car_id" value="<?= $mg_car_id ?>"  placeholder="mg_car_id">
						<input type="hidden" name="model_from_f" id="model_from_f" value="<?= $model_from_f ?>" placeholder="model_from_f">
						<input type="hidden" name="model_to_f" id="model_to_f" value="<?= $model_to_f ?>" placeholder="model_to_f">
						<input type="hidden" name="engine_power_ps" id="engine_power_ps" value="<?= $engine_power_ps ?>" placeholder="engine_power_ps">

						<input list="variant_suggestions" autocomplete="off" type="text" class="form-control px-3" id="variant" name="variant" placeholder="Search Variants"  value="<?= $variant ?>">
						<datalist id="variant_suggestions">
							<?php if(isset($variants)) : ?>
								<?php foreach($variants as $variant): ?>
								<option data-variant_id="<?= $variant['variant_id'] ?>" data-mg_car_id="<?= $variant['mg_car_id'] ?>"
										data-model_from_f="<?= $variant['model_from_f'] ?>" data-model_to_f="<?= $variant['model_to_f'] ?>"
										data-engine_power_ps="<?= $variant['engine_power_ps'] ?>" data-engine_cc="<?= $variant['engine_cc'] ?>"
										value="<?= $variant['variant'] ?>">
								</option>
								<?php endforeach; ?>
							<?php endif; ?>
						</datalist>
					</div>

					<label for="colour_id" class="col-sm-3 col-lg-2 col-xl-2 mt-3 offset-xl-2 col-form-label">Colour</label>
					<div class="col-sm-9 col-lg-4  col-xl-3 mt-3">
						<select class="form-control custom-select" id="colour_id" name="colour_id">
							<option value="">Select Colour</option>
							<?php foreach($colours as $colour): ?>
								<?php $selected = isset($stock_item['colour_id']) && $colour['id'] == $stock_item['colour_id'] ? 'selected' : '';?>
								<option value="<?= $colour['id'] ?>" <?= $selected ?>><?= $colour['colour'] ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>

				<div class="form-group row  my-0">
					<label for="engine_cc" class="col-sm-3 col-lg-2 col-xl-2 mt-3 col-form-label">Engine</label>
					<div class="col-sm-9 col-lg-4 col-xl-3 mt-3">
						<?php $engine_cc = isset($stock_item['engine_cc']) ? $stock_item['engine_cc'] : ''?>
						<input type="number" class="form-control pl-3" id="engine_cc" name="engine_cc" placeholder="Engine" value="<?= $engine_cc ?>">
					</div>
					<label for="year" class="col-sm-3 col-lg-2 col-xl-2 mt-3 offset-xl-2 col-form-label">Year</label>
					<div class="col-sm-9 col-lg-4  col-xl-3 mt-3">
						<?php $year = isset($stock_item['year']) ? $stock_item['year'] : ''?>
						<input list="year_suggestions" autocomplete="off" type="number" class="form-control pl-3"  id="year" name="year" placeholder="Year" min="1991"  max="2021"  value="<?= $year ?>"/>
					</div>
				</div>

				<div class="form-group row  my-0">
					<label for="fuel_type_id" class="col-sm-3 col-lg-2 col-xl-2 mt-3 col-form-label">Fuel</label>
					<div class="col-sm-9 col-lg-4 col-xl-3 mt-3">
						<select class="form-control custom-select" id="fuel_type_id" name="fuel_type_id">
							<option value="">Select Fuel</option>
							<?php foreach($fuel_types as $fuel): ?>
								<?php $selected = isset($stock_item['fuel_type_id']) && $fuel['id'] == $stock_item['fuel_type_id'] ? 'selected' : '';?>
								<option value="<?= $fuel['id'] ?>" <?= $selected ?>><?= $fuel['fuel'] ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<label for="transmission_type_id" class="col-sm-3 col-lg-2 col-xl-2 mt-3 offset-xl-2 col-form-label">Transmission</label>
					<div class="col-sm-9 col-lg-4  col-xl-3 mt-3">
						<select class="form-control custom-select" id="transmission_type_id" name="transmission_type_id">
							<option value="">Select Transmission</option>
							<?php foreach($transmission_types as $transmission): ?>
								<?php $selected = isset($stock_item['transmission_type_id']) && $transmission['id'] == $stock_item['transmission_type_id'] ? 'selected' : '';?>
								<option value="<?= $transmission['id'] ?>" <?= $selected ?>><?= $transmission['transmission'] ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
			</fieldset>

			<div class="row">
				<div class="col-sm-12 mt-3">
					<h5>Service History</h5>
					<hr class="mt-0 mb-2">
				</div>
			</div>

			<fieldset class="form-group border pt-2 pb-4 px-5 col-sm-12  mt-1 mb-3" style="background: #fafafa">
				<!-- <legend class="w-auto px-2">Service Details</legend> -->
				<div class="form-group row my-0">
					<label for="next_service_f" class="col-sm-3 col-lg-2 col-xl-2 mt-3 col-form-label">Next Service</label>
					<div class="input-group col-sm-9 col-lg-4 col-xl-3 mt-3">
						<?php $next_service = isset($stock_item['next_service_f']) && !(empty($stock_item['next_service_f']) ) ? $stock_item['next_service_f'] : '' ?>
						<input type="text" class="form-control datepicker px-3" id="next_service_f" name="next_service_f" placeholder="Select a Date" value="<?= $next_service ?>">
						<div class="input-group-append">
							<div class="input-group-text"><span class="glyphicon glyphicon-calendar fa fa-calendar"></span></div>
						</div>
					</div>
					<label for="nct_due_date_f" class="col-sm-3 col-lg-2 col-xl-2 mt-3 offset-xl-2 col-form-label">NCT Due</label>
					<div class="input-group col-sm-9 col-lg-4  col-xl-3 mt-3">
						<?php $next_nct_due = isset($stock_item['nct_due_date_f']) && !(empty($stock_item['nct_due_date_f']) ) ? $stock_item['nct_due_date_f'] : '' ?>
						<input type="text" class="form-control datepicker px-3" id="nct_due_date_f" name="nct_due_date_f" placeholder="Select a Date" value="<?= $next_nct_due ?>">
						<div class="input-group-append">
							<div class="input-group-text"><span class="glyphicon glyphicon-calendar fa fa-calendar"></span></div>
						</div>
					</div>
				</div>
				<div class="form-group row my-0 py-3">
					<label for="notes" class="col-sm-1 col-form-label">Notes</label>
					<div class="col-sm-12">
						<?php $notes = isset($stock_item['notes']) ? $stock_item['notes'] : '' ?>
						<textarea name="notes" id="notes" name="notes" class="form-control" placeholder="Enter Notes"><?= $notes ?></textarea>
					</div>
				</div>
			</fieldset>

			<div class="row">
				<div class="col-sm-12 mb-3 text-center">
					<button type="submit" class="btn btn-primary mx-2 px-5">Save</button>
					<!-- <button type="reset" class="btn btn-default mx-2 px-5">Reset</button> -->
					<a href="<?= site_url('/vehicles') ?>" class="btn btn-danger mx-2 px-5" role="button">Cancel</a>
				</div>
			</div>

		</form>

	</div>

</div>

<script type="text/javascript">

var baseUrl = "<?= site_url() ?>";

CKEDITOR.replace( 'notes' );

$(document).ready(function() {

	// make
	$('#make_id').on('change',function(event){
		resetSpecs();
		populateModelOptions();
	});

	$('#model_id').on('change',function(event){
		resetSpecs();
		populateVariantOptions();
	});

	// $('#variant').on('select', function() {
	$('#variant').on('change', function() {
		var option = $('#variant_suggestions').find("[value='" + $(this).val() + "']");
		//reset anything previously entered
		// $('#variant_id').val(0);
		// $('#mg_car_id').val(0);
		// $('#model_from_f').val('');
		// $('#model_to_f').val('');
		// $('#engine_power_ps').val(0);
		// $('#engine_cc').val(0);
		if (option.length > 0) {
			$('#variant_id').val(option.data("variant_id"));
			$('#mg_car_id').val(option.data("mg_car_id"));
			$('#model_from_f').val(option.data("model_from_f"));
			$('#model_to_f').val(option.data("model_to_f"));
			$('#engine_power_ps').val(option.data("engine_power_ps"));
			$('#engine_cc').val(option.data("engine_cc"));
		}
	});

	$('#get-data').on('click',function(event){
		populateForm();
	});

});

</script>