<div class="row">
	<div class="col-md-12" style="margin-top:15px; font-size:16px;">
	</div>
</div>
<div class="row">
	<div class="col-lg-12">
		<h2 class="page-header">
			<?= $title ?>
		</h2>
	</div>
	<!-- /.col-lg-12 -->
</div>
<div class="container-fluid">
	<h4 class="animated fadeInDown" align="center">West End Motors Ltd</h4>
	<br>
	<b>MANAGE CUSTOMER INFORMATION.</b>
	<br>
	<div align="right">
		<?php /* <a href="#" data-toggle="modal" data-target="#create" class="create-customer btn btn-primary btn-md">CREATE</a> */?>
		<a href="<?= site_url('/customers/new') ?>" class="btn btn-primary btn-md">CREATE</a>
	</div>
	<br>

	<table id="data-table" class="table table-bordered table-striped display animated fadeInUp dataTable no-footer" role="grid" aria-describedby="data-table_info">
		<thead>
			<tr role="row">
				<th class="sorting_asc" tabindex="0" aria-controls="data-table" rowspan="1" colspan="1" style="width: 23px;" aria-sort="ascending" aria-label="No.: activate to sort column descending">No.</th>
				<th class="sorting" tabindex="0" aria-controls="data-table" rowspan="1" colspan="1" style="width: 240.417px;" aria-label="Customer Name: activate to sort column ascending">Customer Name</th>
				<th class="sorting" tabindex="0" aria-controls="data-table" rowspan="1" colspan="1" style="width: 662.067px;" aria-label="Address: activate to sort column ascending">Address</th>
				<th class="sorting" tabindex="0" aria-controls="data-table" rowspan="1" colspan="1" style="width: 248.517px;" aria-label="Phone No.: activate to sort column ascending">Phone No.</th>
				<th class="sorting" tabindex="0" aria-controls="data-table" rowspan="1" colspan="1" style="width: 52px;" aria-label="A/C No.: activate to sort column ascending">A/C No.</th>
				<th class="sorting" tabindex="0" aria-controls="data-table" rowspan="1" colspan="1" style="width: 27px;" aria-label="Edit: activate to sort column ascending">Edit</th>
				<th class="sorting" tabindex="0" aria-controls="data-table" rowspan="1" colspan="1" style="width: 46px;" aria-label="Delete: activate to sort column ascending">Delete</th>
			</tr>
		</thead>

		<tbody>
			<?php $index = 0; ?>
			<?php foreach($customers as $customer): ?>
				<?php $index++; ?>
				<tr id="<?= $customer['id'] ?>">
					<td class="sorting_1 idx"><?= $index ?></td>
					<td><?= $customer['customer_name'] ?></td>
					<td><?= $customer['address'] ?></td>
					<td><?= $customer['phone'] ?></td>
					<td><?= $customer['id'] ?></td>
					<td class="text-center">
						<?php /*
						<?php $modal_url = site_url('modal/popup/update_customer/'.$customer['id']) ?>
						<a onclick="showAjaxModal('<?= $modal_url ?>');"class="edit-customer btn btn-info btn-sm">
							<i class="fa fa-edit"></i>
						</a>*/?>
						<a href="<?= site_url('/customers/'.$customer['id']) ?>" class="edit-customer btn btn-info btn-sm">
							<i class="fa fa-edit"></i>
						</a>
					</td>
					<td>
						<?php /*
						<?php $delete_url = site_url('admin/customer/delete/'.$customer['id']) ?>
						<a href="<?= $delete_url ?>" class="delete-customer btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
						*/?>
						<a href="#" data-id="<?= $customer['id'] ?>" data-name="<?= $customer['customer_name'] ?>" class="delete-customer btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
			<?php endforeach; ?>

		</tbody>
	</table>

</div>

<script type="application/javascript">

	var baseUrl = "<?= site_url() ?>";

	$(document).ready(function() {

		//Delete Content
		// $(document).on('click', '.delete-customer', function(){
		// 	var id = $(this).attr("id");
		// 	if(confirm("Are you sure you want to remove this?")){
		// 		window.location.href = base_url("admin/customer");
		// 	}
		// 	else{
		// 		return false;
		// 	}
		// });

		//Delete Content
		$(document).on('click', '.delete-customer', function(){
			event.preventDefault();
			var item_id = $(this).data("id");
			var item_desc = $(this).data("name");
			var delete_url = baseUrl + 'customers/delete';
			delete_item(delete_url, item_id, item_desc);
		});

		//Edit Modal for pricing
		$(document).on('click', '.edit-customer', function() {
			$('.modal-title').text('Update Customer Information');
			$('.form-horizontal').show();
		});

	});
</script>
