
<div class="row">
	<div class="col-md-12" style="margin-top:15px; font-size:16px;">
	</div>
</div>
<div class="row">
	<div class="col-xl-10 mb-3">
		<h2 class="page-header">
			<?= $title ?>
		</h2>
	</div>
</div>

<div class="row">
	<div class="col-sm-12 px-5">
		<?php echo validation_errors(); ?>

		<?php echo form_open($form_url, array('id' => 'customer_form')); ?>

		<div class="row">
			<div class="col-sm-12 mt-4">
				<h5>Customer Details</h5>
				<hr class="mt-0 mb-2">
			</div>
		</div>

		<fieldset class="form-group border pt-2 pb-4 px-5 col-sm-12 mt-1 mb-3" style="background: #fafafa">

			<input type="hidden" id="id" name="id" value="<?= $id ?>">

			<div class="form-group row  my-0">
				<label for="customer_name" class="ml-4 col-xl-2 mt-3 col-form-label">Customer Name:</label>
				<div class="col-xl-4 mt-3 pr-5">
					<input type="text" class="form-control pl-3" id="customer_name" name="customer_name" placeholder="Enter Customer Name" value="<?= $customer_name ?>" required minlength="3">
				</div>
			</div>

			<div class="form-group row  my-0">
				<label for="phone" class="ml-4 col-xl-2 mt-3 col-form-label">Phone</label>
				<div class="col-xl-4 mt-3 pr-5">
					<input type="text" class="form-control pl-3" id="phone" name="phone" placeholder="Enter Customer Phone" value="<?= $phone ?>">
				</div>

				<label for="email" class="pl-5 ml-4 col-xl-2 mt-3 col-form-label">Email</label>
				<div class="col-xl-3 mt-3">
					<input type="email" class="form-control pl-3" id="email" name="email" placeholder="Enter Customer Email" value="<?= $email ?>">
				</div>
			</div>

			<div class="form-group row  my-0">
				<label for="status" class="ml-4 col-xl-2 mt-3 col-form-label">Status</label>
				<div class="col-xl-4 mt-3 pr-5">
					<select class="form-control custom-select" id="status" name="status">
						<option value="">Select Status</option>
						<?php foreach($status_list as $status_item): ?>
							<?php $selected =  $status == $status_item['status'] ? 'selected' : '';?>
							<option value="<?= $status_item['status'] ?>" <?= $selected ?>><?= $status_item['status'] ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

		</fieldset>


		<div class="row">
			<div class="col-sm-12 mt-4">
				<h5>Address Details</h5>
				<hr class="mt-0 mb-2">
			</div>
		</div>

		<fieldset class="form-group border pt-2 pb-4 px-5 col-sm-12 mt-1 mb-3" style="background: #fafafa">

			<div class="form-group row  my-0  align-items-center">
				<label for="eir_code" class="ml-4 col-xl-2 mt-3 col-form-label">Eircode:</label>
				<div class="col-xl-3 mt-3">
					<input type="text" class="form-control pl-3" id="eir_code" name="eir_code" placeholder="Enter Eircode" value="<?= $eir_code ?>">
				</div>

				<div class="col-xl-2 mt-3 mx-0 pl-0">
					<button id="get-address" type="button" class="btn btn-secondary mx-0 px-3  btn-sm ">Get info</button>
				</div>

			</div>


			<div class="form-group row  my-0">
				<label for="address1" class="ml-4 col-xl-2 mt-3 col-form-label">Address Line 1:</label>
				<div class="col-xl-4 mt-3 pr-5">
					<input type="text" class="form-control pl-3" id="address1" name="address1" placeholder="Enter Address Line 1" value="<?= $address1 ?>" required>
				</div>

				<label for="address2" class="pl-5 ml-4 col-xl-2 mt-3 col-form-label">Address Line 2:</label>
				<div class="col-xl-3 mt-3">
					<input type="text" class="form-control pl-3" id="address2" name="address2" placeholder="Enter Address Line 2" value="<?= $address2 ?>">
				</div>
			</div>

			<div class="form-group row  my-0">
				<label for="address3" class="ml-4 col-xl-2 mt-3 col-form-label">Town / City:</label>
				<div class="col-xl-4 mt-3 pr-5">
					<input type="text" class="form-control pl-3" id="address3" name="address3" placeholder="Enter Address Line 3" value="<?= $address3 ?>">
				</div>

				<label for="county" class="pl-5 ml-4 col-xl-2 mt-3 col-form-label">County / Region:</label>
				<div class="col-xl-3 mt-3">
					<select class="form-control custom-select" id="county" name="county">
						<option value="">Select County / Region</option>
						<?php foreach($county_list as $county_item): ?>
							<?php $selected =  $county == $county_item['county'] ? 'selected' : '';?>
							<option value="<?= $county_item['county'] ?>" <?= $selected ?>><?= $county_item['county'] ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

			<div class="form-group row  my-0">
				<label for="country" class="ml-4 col-xl-2 mt-3 col-form-label">Country:</label>
				<div class="col-xl-4 mt-3 pr-5">
					<select class="form-control custom-select" id="country_id" name="country_id">
						<option value="">Select Country</option>
						<?php foreach($country_list as $country_item): ?>
							<?php $selected =  $country_id == $country_item['id'] ? 'selected' : '';?>
							<option value="<?= $country_item['id'] ?>" <?= $selected ?>><?= $country_item['country'] ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>

		</fieldset>

		<div class="row">
			<div class="col-sm-12 mb-3 text-center">
				<button type="submit" class="btn btn-primary mx-2 px-5">Save</button>
				<!-- <button type="reset" class="btn btn-default mx-2 px-5">Reset</button> -->
				<a href="<?= site_url('/customers') ?>" class="btn btn-danger mx-2 px-5" role="button">Cancel</a>
			</div>
		</div>
		</form>
	</div>
</div>

<script type="text/javascript">
var baseUrl = "<?= site_url() ?>";

$(document).ready(function() {

	$('#get-address').on('click',function(){
		var input_text = $('#eir_code').val();
		getEircodeDetails(input_text);
	});

});
</script>