<!-- CONTENT-WRAPPER SECTION END-->
<script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"></script>
<!-- Page level plugin CSS-->
<script src="<?php echo base_url();?>assets/js/dataTables.bootstrap4.js"></script>
<script src="<?php echo base_url();?>assets/js/sb-admin.min.js"></script>
<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url();?>assets/js/metisMenu.min.js"></script>
<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url();?>assets/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url();?>assets/js/buttons.flash.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jszip.min.js"></script>
<script src="<?php echo base_url();?>assets/js/pdfmake.min.js"></script>
<script src="<?php echo base_url();?>assets/js/vfs_fonts.js"></script>
<script src="<?php echo base_url();?>assets/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url();?>assets/js/buttons.print.min.js"></script>
