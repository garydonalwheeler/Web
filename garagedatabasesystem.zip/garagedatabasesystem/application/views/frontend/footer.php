<!-- Sticky Footer -->
<footer class="sticky-footer">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <p>Copyright &copy; 2021 WEST END MOTORS LIMITED</p>
    </div>
  </div>
</footer>
