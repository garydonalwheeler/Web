<div class="row">
	<div class="col-md-12" style="margin-top:15px; font-size:16px;">
		<?php
        $success_msg = $this->session->flashdata('success_msg');
        $error_msg  = $this->session->flashdata('error_msg');
        if($success_msg){
            echo $success_msg;
        }
    ?>
	</div>
</div>
<div class="row">
	<div class="col-lg-12">
		<h2 class="page-header"><?php echo $page_title;?></h2>
	</div>
	<!-- /.col-lg-12 -->
</div>
<div class="container-fluid">
      <h4 align="center" class="animated fadeInDown">West End Motors Ltd</h4><br/>
		<b>CASH INVOICE</b>
      <br/>
      
        <br/>
	<div style="overflow-x:auto;">
      <table id="data-table" class="table table-bordered table-striped display animated fadeInUp" style="width:100%;">
        <thead>
	        <tr>
					  <th width="15%">Item No.</th>
					  <th width="12%">Inv No.</th>
					  <th width="15%">Item Name</th>
					  <th width="10%">Description</th>
					  <th width="10%">Category</th>
					  <th width="5%">Quantity</th>
					  <th width="12%">Price</th>
					  <th width="12%">Amount</th>
					  <th width="18%">Created-At</th>
					</tr>
        </thead>
        <?php
		  $result1 = $this->db->get('invoice_order_item')->result_array();
		 $total_rows = $this->db->count_all('invoice_order_item');
		if($total_rows > 0)
		{
			$no = 1;
			foreach ($result1 as $row) {
				echo '<tr>
						<td>'.$no++.'</td>
						<td>'.$row["order_id"].'</td>
						<td>'.$row["item_name"].'</td>
						<td>'.$row["order_description"].'</td>
						<td>'.$row["order_category"].'</td>
						<td>'.$row["order_item_quantity"].'</td>
						<td>'.$row["order_item_price"].'</td>
						<td>'.$row["order_item_actual_amount"].'</td>
						<td>'.$row["created_at"].'</td>
					  </tr>';
				}
		}

        ?>
      </table>
  	</div>
</div>
<br>
