<!-- Sidebar -->
<ul class="sidebar navbar-nav">
   <li class="nav-item <?php if ($page_name == 'dashboard') echo 'active'; ?>">
      <a class="nav-link" href="<?php echo base_url(); ?>admin/dashboard">
      <i class="fa fa-desktop"></i>
      <span><?php echo 'Dashboard'; ?></span>
      </a>
   </li>
   <!-- MANAGE INVOICES -->
   <li class="nav-item <?php if ($page_name == 'manage_invoices') echo 'active'; ?>">
      <a class="nav-link" href="<?php echo base_url(); ?>admin/invoice">
      <i class="fa fa-envelope"></i>
      <span><?php echo 'Manage Invoices'; ?></span>
      </a>
   </li>
   <!-- INVOICE SUMMARY -->
   <li class="nav-item <?php if ($page_name == 'invoice_summary') echo 'active'; ?>">
      <a class="nav-link" href="<?php echo base_url(); ?>admin/sales">
      <i class="fa fa-tasks"></i>
      <span><?php echo 'Invoice Summary'; ?></span>
      </a>
   </li>
   <!-- MANAGE STOCK -->
   <li class="nav-item <?php if ($page_name == 'manage_stock') echo 'active'; ?>">
      <a class="nav-link" href="<?php echo base_url(); ?>admin/stock">
      <i class="fa fa-pencil"></i>
      <span><?php echo 'Manage Stock'; ?></span>
      </a>
   </li>
   <!-- CUSTOMERS -->
   <li class="nav-item <?php if ($page_name == 'manage_customer') echo 'active'; ?>">
      <a class="nav-link" href="<?php echo base_url(); ?>admin/customer">
      <i class="fa fa-users"></i>
      <span><?php echo 'Manage Customers'; ?></span>
      </a>
   </li>
   <!-- DEBTORS -->
   <li class="nav-item <?php if ($page_name == 'manage_debt') echo 'active'; ?> ">
      <a class="nav-link" href="<?php echo base_url(); ?>admin/customer_record_debt">
      <i class="fas fa-fw fa fa-list"></i>
      <span><?php echo 'Manage Debtors'; ?></span>
      </a>
   </li>
   <!-- USER ACCOUNT -->
   <li class="nav-item <?php if ($page_name == 'manage_profile') echo 'active'; ?> ">
      <a class="nav-link" href="<?php echo base_url(); ?>admin/profile">
      <i class="fas fa-fw fa fa-user"></i>
      <span><?php echo 'Staff Profile'; ?></span>
      </a>
   </li>
   <!-- SETTINGS -->
   <li class="nav-item <?php if ($page_name == 'sys_settings') echo 'active'; ?> ">
      <a class="nav-link" href="<?php echo base_url(); ?>admin/settings">
      <i class="fa fa-gears"></i>
      <span> <?php echo 'System Settings'; ?></span>
      </a>
   </li>
</ul>