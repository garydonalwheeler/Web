
<!-- Navbar -->
<ul class="navbar-nav ml-auto mr-0 mr-md-3 my-2 my-md-0">
  <li class="nav-item dropdown no-arrow">
    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fa fa-user fa-fw"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
				<div class="dropdown-divider"></div>
        <a href="<?php echo base_url();?>account/logout" style="margin-left:5px;text-decoration:none;"><i class="fa fa-sign-out fa-fw"></i> Logout</a>

    </div>
  </li>
</ul>
