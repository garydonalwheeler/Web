<div class="row">
   <div class="col-md-12" style="margin-top:15px; font-size:16px;">
      <?php
         $success_msg = $this->session->flashdata('success_msg');
         $error_msg  = $this->session->flashdata('error_msg');
         if($success_msg){
             echo $success_msg;
         }
         ?>
   </div>
</div>
<div class="row">
   <div class="col-lg-12">
      <h2 class="page-header"><?php echo $page_title;?></h2>
   </div>
   <!-- /.col-lg-12 -->
</div>
<div class="container-fluid">
   <h4 align="center" class="animated fadeInDown">West End Motors Ltd</h4>
   <br/>
   <b>CASH INVOICE</b>
   <br />
   <div align="right">
      <a href="<?php echo base_url();?>admin/create/" class="btn btn-primary btn-md">CREATE</a>
   </div>
   <br/>
   <div style="overflow-x:auto;">
      <table id="data-table" class="table table-bordered table-striped display animated fadeInUp" style="width:100%;">
         <thead>
            <tr>
               <th>Invoice No.</th>
               <th>Date</th>
               <th>Customer Name</th>
               <th>Address</th>
               <th>Print</th>
               <th>Show</th>
               <th>Edit</th>
               <th>Delete</th>
            </tr>
         </thead>
         <?php
            $result1 = $this->db->get('invoices_test')->result_array(); // changed from invoice_order to invoices_test 20/11/2020 for testing
            $total_rows = $this->db->count_all('invoices_test'); // changed from invoice_order to invoices_test 20/11/2020 for testing
            if($total_rows > 0)
            {
            foreach ($result1 as $row) {
            echo '
              <tr>
            	<td>'.$row["order_id"].'</td>
            	<td>'.$row["order_datetime"].'</td>
            	<td>'.$row["order_receiver_name"].'</td>
            	<td>'.$row["order_receiver_addr"].'</td>
            
            	<td class="text-center"><a href="print_pdf/'.$row["order_id"].'">Print</a></td>
            	<td class="text-center"><a href="#" class="show-invoice btn btn-info btn-sm"
            
            	data-id 		="'.$row['order_id'].'"
                data-date		="'.$row['order_date'].'"
            	data-name		="'.$row['order_receiver_name'].'"
                data-total		="'.$row['order_total'].'"
            	data-paid		="'.$row['paid'].'"
            	data-balance	="'.$row['balance'].'"
            	data-phone		="'.$row['order_receiver_phone'].'">
            	<i class="fa fa-eye"></i>
            	</a>
            	</td>
            	<td class="text-center"><a href="update/'.$row["order_id"].'" class="edit-appointment btn btn-warning btn-sm" >
            	<i class="fa fa-edit"></i></a></td>
            
            	<td><a href="invoice/delete/'.$row["order_id"].'" class="delete-invoice btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a></td>
              </tr>
            ';
            }
            }
            else {
            echo '<tr><td colspan="8">No Invoice Data Entry</td><tr>';
            }
                ?>
      </table>
   </div>
</div>
<br>
<!-- Modal Form show staff -->
<div id="show-invoice" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title" id="exampleModalLabel"></h4>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
            </button>
         </div>
         <div class="modal-body">
            <div class="form-group">
               <label class="col-md-4" for="">Order No:</label>
               <b id="s-id"/>
            </div>
            <div class="form-group">
               <label class="col-md-4" for="">Order-Date:</label>
               <b id="s-date"/>
            </div>
            <div class="form-group">
               <label class=" col-md-4" for="">Client-Name:</label>
               <b id="s-name"/>
            </div>
            <div class="form-group">
               <label class="col-md-4" for="">Invoice Total:</label>
               <b id="s-total"/>
            </div>
            <div class="form-group">
               <label class="col-md-4" for="">Amount Paid:</label>
               <b id="s-paid"/>
            </div>
            <div class="form-group">
               <label class="col-md-4" for="">Balance:</label>
               <b id="s-balance"/>
            </div>
            <div class="form-group">
               <label class="col-md-4" for="">Phone:</label>
               <b id="s-phone"/>
            </div>
         </div>
         <div class="modal-footer">
            West End Motors Ltd
         </div>
      </div>
   </div>
</div>
<script type="application/javascript">
   //Delete Content
   $(document).on('click', '.delete-invoice', function(){
     var id = $(this).attr("id");
   if(confirm("Are you sure you want to remove this?"))
   {
   window.location.href = base_url("admin/invoice");
   }
   else
   {
   return false;
   }
   });
   
   //show modal for staff
       				$(document).on('click', '.show-invoice', function() {
           			$('#show-invoice').modal('show');
           			$('#s-id').text($(this).data('id'));
           			$('#s-date').text($(this).data('date'));
           			$('#s-name').text($(this).data('name'));
           			$('#s-total').text($(this).data('total'));
   					$('#s-paid').text($(this).data('paid'));
   					$('#s-balance').text($(this).data('balance'));
   					$('#s-phone').text($(this).data('phone'));
           			$('.modal-title').text('Invoice Data Information');
       });
</script>