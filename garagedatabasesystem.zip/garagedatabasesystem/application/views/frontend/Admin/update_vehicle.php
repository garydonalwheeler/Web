<?php
   $single_stock_info = $this->db->get_where('garage_vehicles', array('id' => $param2))->result_array();
   foreach ($single_stock_info as $row) {
   ?>
<form role="form" class="form-horizontal" action="<?php echo base_url(); ?>admin/vehicles/update/<?=$row['id']; ?>" method="post" enctype="multipart/form-data">
   <div class="form-group">
      <div class="row">
         <label for="field-1" class="col-md-4 control-label">ID:</label>
         <div class="col-md-8">
            <b><?=$row['id'];?></b>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="row">
         <label class="col-md-4 control-label" for="field-ta">Vehicle Reg:</label>
         <div class="col-md-8">
            <input type="text" class="form-control" name="vehiclereg" id="e-price" required value="<?= $row['vehiclereg']; ?>"readonly/>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="row">
         <label class="control-label col-md-4" for="field-1">Customer No:</label>
         <div class="col-md-8">
            <input type="text" class="form-control" name="customer" id="field-1" required value="<?= $row['customer']; ?>"/>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="row">
         <label class="control-label col-md-4" for="field-1">Make & Model:</label>
         <div class="col-md-8">
            <input type="text" class="form-control" name="makemodel" id="field-1" required value="<?= $row['makemodel']; ?>"/>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="row">
         <label class="col-md-4 control-label" for="field-ta">Last Mileage:</label>
         <div class="col-md-8">
            <input type="text" class="form-control" name="lastmileage" id="field-1" required value="<?= $row['lastmileage']; ?>"/>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="row">
         <label class="col-md-4 control-label" for="field-ta">Next Service Due:</label>
         <div class="col-md-8">
            <input type="text" class="form-control" name="nextservicedue" id="field-1" required value="<?= $row['nextservicedue']; ?>"/>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="row">
         <label class="col-md-4 control-label" for="field-ta">Notes:</label>
         <div class="col-md-8">
            <textarea class="form-control" name="notes" id="e-price" required value="<?= $row['notes']; ?>"/>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="col-md-12n pull-right" style="margin:5px 15px;">
         <button type="submit" class="btn btn-success">Update</button>
         <span class="fa fa-plus"></span>
         <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
         <span class="fa fa-times"></span>
      </div>
   </div>
</form>
<?php } ?>