<?php
   $single_stock_info = $this->db->get_where('invoice_stock_item', array('rate_id' => $param2))->result_array();
   foreach ($single_stock_info as $row) {
   ?>
<form role="form" class="form-horizontal" action="<?php echo base_url(); ?>admin/stock/update/<?=$row['rate_id']; ?>" method="post" enctype="multipart/form-data">
   <div class="form-group">
      <div class="row">
         <label for="field-1" class="col-md-4 control-label">ID:</label>
         <div class="col-md-8">
            <b><?=$row['rate_id'];?></b>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="row">
         <label class="control-label col-md-4" for="field-1">Description</label>
         <div class="col-md-8">
            <input type="text" class="form-control" name="description" id="field-1" required value="<?= $row['description']; ?>"/>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="row">
         <label class="control-label col-md-4" for="field-1">Category</label>
         <div class="col-md-8">
            <input type="text" class="form-control" name="category" id="field-1" required value="<?= $row['category']; ?>"readonly/>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="row">
         <label class="col-md-4 control-label" for="field-ta">Stock Available</label>
         <div class="col-md-8">
            <input type="text" class="form-control" name="current_stock" id="field-1" required value="<?= $row['current_stock']; ?>"/>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="row">
         <label class="col-md-4 control-label" for="field-ta">Unit-Price:</label>
         <div class="col-md-8">
            <input type="text" class="form-control" name="unit_price" id="e-price" required value="<?= $row['unit_price'];?>"/>
         </div>
      </div>
   </div>
   <div class="form-group">
      <div class="col-md-12n pull-right" style="margin:5px 15px;">
         <button type="submit" class="btn btn-success">Update</button>
         <span class="fa fa-plus"></span>
         <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
         <span class="fa fa-times"></span>
      </div>
   </div>
</form>
<?php } ?>