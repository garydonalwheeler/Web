<div class="row">
   <div class="col-md-12" style="margin-top:15px; font-size:16px;">
      <?php
         $success_msg = $this->session->flashdata('success_msg');
         $error_msg  = $this->session->flashdata('error_msg');
         if($success_msg){
             echo $success_msg;
         }
         ?>
   </div>
</div>
<div class="row">
   <div class="col-lg-12">
      <h2 class="page-header"><?php echo $page_title;?></h2>
   </div>
   <!-- /.col-lg-12 -->
</div>
<div class="container-fluid table-responsive">
   <h4 align="center" class="animated fadeInDown">West End Motors Ltd</h4>
   <br/>
   <b>MANAGE VEHICLE INFORMATION</b>
   <br/>
   <div align="right">
      <a href="#" class="create-price btn btn-primary btn-md">CREATE</a>
   </div>
   <br/>
   <table id="data-table" class="table table-bordered table-striped animated fadeInUp" width="100%" cellspacing="0">
      <thead>
         <tr>
            <th>No.</th>
            <th>Vehicle Registration</th>
            <th>Make and Model</th>
            <th>Engine CC</th>
            <th>VIN</th>
            <th>Colour</th>
            <th>Fuel Type</th>
            <th>A/C No.</th>
            <th>Show</th>
            <th>Edit</th>
            <th>Delete</th>
         </tr>
      </thead>
  
      <?php
         $result1 = $this->db->get('garage_vehicles')->result_array();
         $total_rows = $this->db->count_all('garage_vehicles');
         if($total_rows > 0)
         {
         $no=1;
         foreach ($result1 as $row) { ?>
      <tr>
         <td><?=$no++ ?></td>
         <td><?=$row["vehiclereg"] ?></td>
         <td><?=$row["makemodel"] ?></td>
         <td><?=$row["cc"] ?></td>
         <td><?=$row["vin"] ?></td>
         <td><?=$row["colour"] ?></td>
         <td><?=$row["fuel"] ?></td>
         <td><?=$row["customer"] ?></td>
         <td class="text-center"><a href="#" class="show-vehicle btn btn-info btn-sm"

            data-id ="<?=$row['id'] ?>"
            data-vehiclereg="<?=$row['vehiclereg'] ?>"
            data-customer="<?=$row['customer'] ?>"
            data-makemodel="<?=$row['makemodel'] ?>"
			data-colour="<?=$row['colour'] ?>"
			data-fuel="<?=$row['fuel'] ?>"
            data-lastmileage="<?=$row['lastmileage'] ?>"
            data-nextservicedue="<?=$row['nextservicedue'] ?>"
            data-notes="<?=$row['notes'] ?>"
            data-vin="<?=$row['vin'] ?>">
            <i class="fa fa-eye"></i>
            </a>
         </td>
         <td class="text-center">
            <a  onclick="showAjaxModal('<?= base_url();?>modal/popup/update_vehicle/<?= $row['id']?>');"
               class="edit-vehicle btn btn-success btn-sm">
            <i class="fa fa-edit"></i>
            </a>
         </td>
         <td><a href="vehicles/delete/<?=$row["id"] ?>" class="delete-vehicle btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a></td>
      </tr>
      <?php } }?>

   </table>
</div>
<br>
<!-- Modal Form -->
<div id="show-vehicle" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header" >
            <h4 class="modal-title" id="exampleModalLabel"></h4>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
            </button>
         </div>
         <div class="modal-body">
            <div class="form-group">
               <label class="control-label col-md-4" for="">ID:</label>
               <b id="s-id"></b>
            </div>
            <div class="form-group">
               <label class="control-label col-md-4" for="">Vehicle Reg:</label>
               <b id="s-vehiclereg"></b>
            </div>
            <div class="form-group">
               <label class="control-label col-md-4" for="">Make & Model:</label>
               <b id="s-makemodel"></b>
            </div>
            <div class="form-group">
               <label class="control-label col-md-4" for="">Colour:</label>
               <b id="s-colour"></b>
            </div>
            <div class="form-group">
               <label class="control-label col-md-4" for="">Fuel:</label>
               <b id="s-fuel"></b>
            </div>
            <div class="form-group">
               <label class="control-label col-md-4" for="">Next Service Due:</label>
               <b id="s-nextservicedue"></b>
            </div>
            <div class="form-group">
               <label class="control-label col-md-4" for="">Last Mileage:</label>
               <b id="s-lastmileage"></b>
            </div>
            <div class="form-group">
               <label class="control-label col-md-4" for="">Customer:</label>
               <b id="s-customer"></b>
            </div>
            <div class="form-group">
               <label class="control-label col-md-4" for="">Notes:</label><br/>
               <b id="s-notes"></b>
            </div>
         </div>
         <div class="modal-footer">
            West End Motors Ltd
         </div>
      </div>
   </div>
</div>
<!-- Modal Form Create Stock Item -->
<div id="create" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title" id="exampleModalLabel"></h4>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
            </button>
         </div>
         <div class="modal-body">
            <form class="form-horizontal" action="<?php echo base_url();?>admin/vehicles/create" method="post">
               <div class="form-group">
                  <div class="row">
                     <label class="control-label col-md-4" for="title">Vehicle Registration:</label>
                     <div class="col-md-8">
                        <input name="vehiclereg" id="id" class="form-control" required/>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <label class="control-label col-md-4" for="title">Customer:</label>
                     <div class="col-md-8">
                        <input name="customer" id="id" class="form-control" required/>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <label class="control-label col-md-4" for="title">Make & Model:</label>
                     <div class="col-md-8">
                        <input name="makemodel" id="id" class="form-control" required/>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <label class="control-label col-md-4" for="body">Year of Manufacture: :</label>
                     <div class="col-md-8">
                        <input name="yearofmanufacture" id="id" class="form-control" required/>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <label class="control-label col-md-4" for="body">Engine Size: :</label>
                     <div class="col-md-8">
                        <input name="cc" id="id" class="form-control" required/>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <label class="control-label col-md-4" for="body">VIN :</label>
                     <div class="col-md-8">
                        <input name="vin" id="id" class="form-control" required/>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <label class="control-label col-md-4" for="title">Colour:</label>
                     <div class="col-md-8">
                        <input name="colour" id="id" class="form-control" required/>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <label class="control-label col-md-4" for="body">Fuel :</label>
                     <div class="col-md-8">
                        <input name="fuel" id="id" class="form-control" required/>
                     </div>
                  </div>
               </div>

               <div class="form-group">
                  <div class="row">
                     <label class="control-label col-md-4" for="body">Last Mileage :</label>
                     <div class="col-md-8">
                        <input name="lastmileage" id="id" class="form-control" required/>
                     </div>
                  </div>
               </div>


               <div class="form-group">
                  <div class="col-md-12n pull-right" style="margin:5px 10px;">
                     <button class="btn btn-success fa fa-plus" type="submit" id="add">Save Data
                     </button>
                     <button class="btn btn-danger fa fa-times" type="button" data-dismiss="modal">
                     Close
                     </button>
                  </div>
               </div>
            </form>
         </div>
         <div class="modal-footer">
            West End Motors Ltd
         </div>
      </div>
   </div>
</div>
<!--Modal Form Closed-->
<script type="application/javascript">
   //Delete Content
   $(document).on('click', '.delete-vehicle', function(){
       var id = $(this).attr("id");
     if(confirm("Are you sure you want to remove this?"))
     {
   	window.location.href = base_url("admin/vehicles");
     }
     else
     {
   	return false;
     }
     });
   
   //Show Modal for Vehicle
        $(document).on('click', '.show-vehicle', 
        	function() 
        	{
             	$('#show-vehicle').modal('show');
             	$('#s-id').text($(this).data('id'));
             	$('#s-vehiclereg').text($(this).data('vehiclereg'));
             	$('#s-customer').text($(this).data('customer'));
             	$('#s-makemodel').text($(this).data('makemodel'));
             	$('#s-colour').text($(this).data('colour'));
             	$('#s-fuel').text($(this).data('fuel'));
             	$('#s-lastmileage').text($(this).data('lastmileage'));
            	$('#s-nextservicedue').text($(this).data('nextservicedue'));
             	$('#s-vin').text($(this).data('vin'));
             	$('#s-notes').text($(this).data('notes'));
             	$('.modal-title').text('Vehicle Information');
         	});
   
   //Edit Modal for stock
         $(document).on('click', '.edit-vehicle', 
         	function() 
         	{
             	$('.modal-title').text('Update Vehicle Information');
             	$('.form-horizontal').show();
         	});
   
   //Call to the form-modal
         $(document).on('click','.create-price', 
         	function() 
         	{
             	$('#create').modal('show');
            	$('.form-horizontal').show();
   				$('.modal-title').text('Enter New Vehicle Data');
         	});
   
</script>