<?php
	$invoice_order_total = $this->db->count_all('invoices_test'); // changed from invoice_order to invoices_test 20/11/2020 for testing
	$invoice_order_item_total = $this->db->count_all('invoice_order_item');
	$total_customers = $this->db->count_all('customers');
	$total_debtors = $this->db->count_all('record_debt');
	$total_vehicles = $this->db->count_all('garage_vehicles');
	$total_suppliers = $this->db->count_all('suppliers');
	$invoice_stock_item_total = $this->db->count_all('invoice_stock_item'); // changed from invoice_order to invoices_test 20/11/2020 for testing


?>
<!-- Breadcrumbs-->
	<ol class="breadcrumb animated slideInDown">
	  <li class="breadcrumb-item">
	    <a href="<?php echo base_url(); ?>admin/dashboard" style="text-decoration:none;">Dashboard</a>
	  </li>
	  <li class="breadcrumb-item active">Overview</li>
	</ol>

<!-- /.row -->
<!-- Icon Cards-->
<div class="row">
  <div class="col-xl-4 col-sm-6 mb-3 animated fadeInLeft">
    <div class="card text-white bg-primary o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fa fa-envelope fa-1x"></i>
        </div>
        <div class="mr-5"><b>[<?= $invoice_order_total ?>]</b> Manage Invoices</div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php  echo base_url();?>admin/invoice">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fa fa-arrow-circle-right"></i>
        </span>
      </a>
    </div>
  </div>
  <div class="col-xl-4 col-sm-6 mb-3 animated fadeInLeft">
    <div class="card text-white bg-secondary o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fa fa-tasks fa-1x"></i>
        </div>
        <div class="mr-5"><b>[<?= $invoice_order_item_total ?>]</b> Invoice Summary</div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php  echo base_url();?>admin/sales">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fa fa-arrow-circle-right"></i>
        </span>
      </a>
    </div>
  </div>
  <div class="col-xl-4 col-sm-6 mb-3 animated fadeInRight">
    <div class="card text-white bg-info o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fa fa-tachometer fa-1x"></i>
        </div>
        <div class="mr-5"><b>[<?= $invoice_stock_item_total ?>]</b> Manage Stock</div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php  echo base_url();?>admin/stock">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fa fa-arrow-circle-right"></i>
        </span>
      </a>
    </div>
  </div>
  <div class="col-xl-4 col-sm-6 mb-3 animated fadeInLeft">
    <div class="card text-white bg-success o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fa fa-users fa-1x"></i>
        </div>
        <div class="mr-5"><b>[<?= $total_customers;?>]</b> Manage Customers</div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php echo base_url();?>admin/customer">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fa fa-arrow-circle-right"></i>
        </span>
      </a>
    </div>
  </div>
    <div class="col-xl-4 col-sm-6 mb-3 animated fadeInRight">
    <div class="card text-white bg-warning o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fa fa-book fa-1x"></i>
        </div>
        <div class="mr-5"><b>[<?= $total_debtors;?>]</b> Manage Debtors</div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php echo base_url();?>admin/customer_record_debt">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fa fa-arrow-circle-right"></i>
        </span>
      </a>
    </div>
  </div>
  <div class="col-xl-4 col-sm-6 mb-3 animated fadeInRight">
    <div class="card text-white bg-danger o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fa fa-shopping-cart fa-1x"></i>
        </div>
        <div class="mr-5"><b>[<?= $total_suppliers;?>]</b> Manage Suppliers</div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php echo base_url();?>admin/supplier">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fa fa-arrow-circle-right"></i>
        </span>
      </a>
    </div>
  </div>

  <div class="col-xl-4 col-sm-6 mb-3 animated fadeInLeft">
    <div class="card text-white bg-dark o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fa fa-truck fa-1x"></i>
        </div>
        <div class="mr-5"><b>[<?= $total_vehicles;?>]</b> Manage Vehicles</div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php echo base_url();?>admin/vehicles">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fa fa-arrow-circle-right"></i>
        </span>
      </a>
    </div>
  </div>
    <div class="col-xl-4 col-sm-6 mb-3 animated fadeInLeft">
    <div class="card text-white bg-primary o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fa fa-male fa-1x"></i>
        </div>
        <div class="mr-5">Manage Staff</div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php echo base_url(); ?>admin/profile">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fa fa-arrow-circle-right"></i>
        </span>
      </a>
    </div>
  </div>
  <div class="col-xl-4 col-sm-6 mb-3 animated fadeInRight">
    <div class="card text-white bg-danger o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fa fa-gears fa-1x"></i>
        </div>
        <div class="mr-5">System Settings</div>
      </div>
      <a class="card-footer text-white clearfix small z-1" href="<?php echo base_url();?>admin/settings">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fa fa-arrow-circle-right"></i>
        </span>
      </a>
    </div>
  </div>

</div>
