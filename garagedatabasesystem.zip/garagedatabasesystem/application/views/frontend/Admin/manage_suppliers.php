<div class="row">
   <div class="col-md-12" style="margin-top:15px; font-size:16px;">
      <?php
         $success_msg = $this->session->flashdata('success_msg');
         $error_msg  = $this->session->flashdata('error_msg');
         if($success_msg){
         	echo $success_msg;
         }
         ?>
   </div>
</div>
<div class="row">
   <div class="col-lg-12">
      <h2 class="page-header"><?php echo $page_title;?></h2>
   </div>
   <!-- /.col-lg-12 -->
</div>
<div class="container-fluid">
   <h4 align="center" class="animated fadeInDown">West End Motors Ltd</h4>
   <br/>
   <b>MANAGE SUPPLIER INFORMATION.</b>
   <br/>
   <div align="right">
      <a href="#" data-toggle="modal" data-target="#create" class="create-supplier btn btn-primary btn-md">CREATE</a>
   </div>
   <br/>
   <div style="overflow-x:auto;">
      <table id="data-table" class="table table-bordered table-striped display animated fadeInUp">
         <thead>
            <tr>
               <th>No.</th>
               <th>Supplier Name</th>
               <th>Address</th>
               <th>Phone No.</th>
               <th>A/C No.</th>
               <th>Edit</th>
               <th>Delete</th>
            </tr>
         </thead>
         <?php
            $total_rows = $this->db->count_all('suppliers');
            if($total_rows > 0)
            {
            $no=1;
            foreach ($supplier_info as $row) { ?>
         <tr>
            <td><?=$no++?></td>
            <td><?=$row["supplier_name"] ?></td>
            <td><?=$row["address"] ?></td>
            <td><?=$row["phone"] ?></td>
            <td><?=$row["id"] ?></td>
            <td class="text-center">
               <a  onclick="showAjaxModal('<?= base_url();?>modal/popup/update_supplier/<?= $row["id"]?>');"
                  class="edit-supplier btn btn-info btn-sm">
               <i class="fa fa-edit"></i>
               </a>
            </td>
            <td>
               <a href="supplier/delete/<?=$row['id'] ?>" class="delete-supplier btn btn-danger btn-sm">
               <i class="fa fa-trash-o"></i>
               </a>
            </td>
         </tr>
         <?php } }?>
      </table>
   </div>
</div>
<!-- Modal Form Create Customer -->
<div id="create" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h4 class="modal-title" id="exampleModalLabel">Create Supplier</h4>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
            </button>
         </div>
         <div class="modal-body">
            <form class="form-horizontal" action="<?php echo base_url();?>admin/supplier/create" method="post">
               <div class="form-group">
                  <div class="row">
                     <label class="control-label col-sm-4"for="title">Account ID:</label>
                     <div class="col-sm-8">
                        <input name="id" id="id" class="form-control" required/>
                     </div>
                     </row>
                  </div>
                  <br/>
                  <div class="form-group">
                     <div class="row">
                        <label class="control-label col-sm-4"for="title">Name:</label>
                        <div class="col-sm-8">
                           <input name="supplier_name" id="name" class="form-control" required/>
                        </div>
                        </row>
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="row">
                        <label class="control-label col-md-4" for="body">Address :</label>
                        <div class="col-md-8">
                           <input name="supplier_address" id="address" class="form-control" required/>
                        </div>
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="row">
                        <label class="control-label col-md-4" for="body">Phone :</label>
                        <div class="col-md-8">
                           <input name="supplier_phone" id="tell" class="form-control" required/>
                        </div>
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="row">
                        <label class="control-label col-md-4" for="title">Status :</label>
                        <div class="col-md-8">
                           <select name="status" id="status" class="form-control" required>
				               <option value="Retail">Retail</option>
				               <option value="Trade">Trade</option>
				               <option value="Wholesale">Wholesale</option>
				               <option value="Account">Account</option>
				               <option value="Company">Company</option>
				               <option value="Cash">Cash</option>
				               <option value="Regular">Regular</option>
				               <option value="New">New</option>
                           </select>
                        </div>
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="col-md-12n pull-right" style="margin:5px 10px;">
                        <button class="btn btn-success" type="submit" id="add">
                        <span class="fa fa-plus"></span> Save Data
                        </button>
                        <button class="btn btn-danger" type="button" data-dismiss="modal">
                        <span class="fa fa-times"></span>Close
                        </button>
                     </div>
                  </div>
            </form>
            </div>
            <div class="modal-footer">
               West End Motors Ltd
            </div>
         </div>
      </div>
   </div>
</div>
<!--Modal Form Closed-->
<script type="application/javascript">
   $(document).ready(function(){
   	//Delete Content
   	$(document).on('click', '.delete-supplier', function(){
   			var id = $(this).attr("id");
   			if(confirm("Are you sure you want to remove this?"))
   			{
   			window.location.href = base_url("admin/supplier");
   			}
   			else
   			{
   			return false;
   			}
   		});
   
   });
   
</script>
<script type="text/javascript">
   $(document).ready(function(){
   	//Edit Modal for pricing
   		$(document).on('click', '.edit-supplier', function() {
   				$('.modal-title').text('Update Supplier Information');
   				$('.form-horizontal').show();
   		});
   });
</script>