<?php
//print_invoice.php
$result1 = $this->db->get_where('invoices_test', array('order_id' => $param2))->result_array();
$company = $this->db->get_where('settings', array('type' => 'company'))->row()->description;
$address = $this->db->get_where('settings', array('type' => 'address'))->row()->description;
$phone = $this->db->get_where('settings', array('type' => 'phone'))->row()->description;
if($result1 > 0)
{
 require_once 'pdf.php';
 $output = '';
 
	foreach ($result1 as $row) 
	{
	  $output .= '
	   <table width="100%" border="1" cellpadding="10" cellspacing="0">
		
		<tr>
		 <td colspan="2">
		  <table width="100%" cellpadding="10">
		  <tr>
		  <td colspan="8" style="text-align:left; font-size:26px;"><b>'.$company.'</b><br/>'.$address.'<br/>'.$phone.'</td>
		  <td><img src="assets/img/bg.jpg" alt="" border=3 height=100 width=100></img></td>
		  </tr>
		   
		   <tr>
			<td width="50%">

			 <b>Customer Details:</b><br />
			 Name     : 	'.$row["order_receiver_name"].'<br /> 
			 Address  : 	'.$row["order_receiver_addr"].'<br />
			 Phone No.: 	'.$row["order_receiver_phone"].'<br />
			</td>
			<td width="50%"><br/>
			 Invoice No. : 	'.$row["order_id"].'<br />
			 Invoice Date : '.$row["order_date"].'<br />
			 Order No: : 	'.$row["order_no"].'<br />
			</td>
		   </tr>
		  </table>
		  <br />
		  <br/>
		  <table width="100%" border="5" cellpadding="8" cellspacing="0">
		   <tr>
			<th width="6%"> No.</th>
			<th width="30%">Job Description</th>
			<th width="25%">Parts</th>
			<th width="6%">Cat</th>
			<th width="6%">Qty</th>
			<th>Price</th>
			<th>RRP</th>
			<th rowspan="2">Total ex VAT</th>
		   </tr>
		   <tr>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
		   </tr>';
		$result2 = $this->db->get_where('invoice_order_item', array('order_id' => $param2))->result_array();
		$count = 0;
		foreach($result2 as $sub_row)
		{
		   $vat = 1.21;
		   $count++;
		   $output .= '
		   <tr>
			<td>'.$count.'</td>
			<td>'.$sub_row["item_name"].'</td>
			<td>'.$sub_row["order_description"].'</td>
			<td>'.$sub_row["order_category"].'</td>
			<td>'.$sub_row["order_item_quantity"].'</td>
			<td>'.$sub_row["order_item_price"].'</td>
			<td>'.$sub_row["order_item_actual_amount"].'</td>
			<td>'.$sub_row["order_item_actual_amount"]*.825.'</td>
		   </tr>
		   ';
		  }
		  $output .= '
		 
		   <tr>
		   <td colspan="7"><b>VAT @ 21%:</b></td>
		   <td align="right"><b>'.$row["order_total"]*0.21.'</b></td>
		  </tr>
		  <tr>
		   <td colspan="7"><b>Invoice Total inc VAT :</b></td>
		   <td align="right"><b>'.$row["order_total"].'</b></td>
		  </tr>
		  <tr>
		   <td colspan="7"><b>Amount Paid :</b></td>
		   <td align="right"><b>'.$row["paid"].'</b></td>
		  </tr>
		  <tr>
		   <td colspan="7"><b>Balance Outstanding :</b></td>
		   <td align="right"><b>'.$row["balance"].'</b></td>
		  </tr>
		  ';
		  $output .= '
      </table>
     </td>
    </tr>
   </table>
  ';
 }
 $pdf = new Pdf();
 $file_name = 'Invoice-'.$row["order_no"].'.pdf';
 $pdf->loadHtml($output);
 $pdf->render();
 $pdf->stream($file_name, array("Attachment" => false));
}
?>