<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/animate.min.css">
<link type="text/css" href="https://bootswatch.com/3/spacelab/bootstrap.min.css" rel="stylesheet">
<link type="text/css" href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
<link type="text/css" href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
