<?php
defined('BASEPATH') OR exit('No direct script access allowed');


// customers
$route['customers/index'] = 'customers/index';
$route['customers/create'] = 'customers/create';
$route['customers/update'] = 'customers/update';
$route['customers/delete'] = 'customers/delete';

$route['customers/(:any)'] = 'customers/view/$1';
$route['customers'] = 'customers/index';
$route['customer'] = 'customers/index'; // if misspelled, redirect

// customers ajax pages
$route['customers/ajax_(:any)'] = 'customers/ajax_$1';
$route['customers/ajax_(:any)/(:any)'] = 'customers/ajax_$1/$2';


// vehicles
$route['vehicles/index'] = 'vehicles/index';
$route['vehicles/create'] = 'vehicles/create';
$route['vehicles/update'] = 'vehicles/update';
$route['vehicles/delete'] = 'vehicles/delete';

// vehicles ajax pages
$route['vehicles/ajax_get_variants'] = 'vehicles/ajax_get_variants';
$route['vehicles/ajax_(:any)'] = 'vehicles/ajax_$1';
$route['vehicles/ajax_(:any)/(:any)'] = 'vehicles/ajax_$1/$2';

$route['vehicles/(:any)'] = 'vehicles/view/$1';
$route['vehicles'] = 'vehicles/index';


// $route['default_controller'] = 'pages/view';
// $route['(:any)'] = 'pages/view/$1';

$route['default_controller'] = 'account';
// $route['default_controller'] = 'pages/view';
// $route['(:any)'] = 'pages/view/$1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
